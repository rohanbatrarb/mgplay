<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Live View</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
   <link rel="stylesheet" href="plugins/custombox.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
  include 'session.php';
  include  'nav_barr.php';
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
           
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
            <?php extract($_REQUEST);
            
                $sql = mysqli_query($link,"SELECT * FROM live_quiz_category WHERE id='$id'");
                $res = mysqli_fetch_assoc($sql);
                ?>
                <div class="row">
                  <div class="col-md-8">
                      <div class="card-box">
                          Match Title:<h4 class="text-uppercase font-600"> <?php echo $res['quiz_name'];?></h4>
                          <p class="text-uppercase font-600"> <?php echo $res['sub_name'];?></p>
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="card-box">
                          Match Status:<h4 class="text-uppercase font-600"> <?php echo $res['status'];?></h4>
                          <p><?php echo $res['date'].' '.$res['time'];?></p>
                      </div>
                  </div>
                  <div class="col-sm-12">
                    <div class="card-box widget-inline">
                      <div class="row">
                        <div class="col-lg-3 col-sm-6">
                          <div class="widget-inline-box text-center">
                            <h3><i class="text-primary md md-attach-money"></i> <b data-plugin="counterup">
                              <?php echo $res['prize_pool'];?>                             
                            </b></h3>
                            <h4 class="text-muted">Winning Prize</h4>
                          </div>
                        </div>
                        
                        <div class="col-lg-3 col-sm-6">
                          <div class="widget-inline-box text-center">
                            <h3><i class="text-custom md md-style"></i> <b data-plugin="counterup"><?php echo $res['total_join'].'/'.$res['total_player'];?></b></h3>
                            <h4 class="text-muted">Join/Allow</h4>
                          </div>
                        </div>
                        
                        <div class="col-lg-3 col-sm-6">
                          <div class="widget-inline-box text-center">
                            <h3><i class="text-pink md md-keyboard-tab"></i> <b data-plugin="counterup"><?php echo $res['entry_fee'];?></b></h3>
                            <h4 class="text-muted">Entry Fee</h4>
                          </div>
                        </div>
                        
                        <div class="col-lg-3 col-sm-6">
                          <div class="widget-inline-box text-center b-0">
                            <a href="live_question_list.php?id=<?php echo $id;?>"><h3><i class="text-purple md md-account-child"></i> <b data-plugin="counterup"><?php echo $res['total_question'];?></b></h3></a>
                            <a href="live_question_list.php?id=<?php echo $id;?>"><h4 class="text-muted">Total Question</h4></a>
                          </div>
                        </div>
                        
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="row row-eq-height">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="card-box">
                        <div class="row">
                          <div class="col-sm-6"><h4 class="text-uppercase font-600">Join User</h4></div>
                          <div class="col-sm-6 text-right"><a href="live_distribution.php?id=<?php echo $id?>"><button class="btn btn-primary">Prize Distribution</button></a> <a href="update_live_quiz.php?autopayment=1&id=<?php echo $id?>"><button class="btn btn-warning">Auto Payment</button></a></div>
                        </div>
                          
                          <hr>
                          <div class="card-body table-responsive">
                <table id="example1" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>ID</th>
                 <th>Username</th>
                  <th>Score</th>
                  <th>Rank</th>
                  <th>Amount</th>
                  <th>Operation</th>
                  
                </tr>
                </thead><tbody> 
                
                
                <?php 
                $id = $res['id'];
               $str="SELECT * FROM live_quiz_join WHERE quiz_id='$id'";
                $query=mysqli_query($link,$str);
                    $i=1;
                    $rank=1;
                    $flag="";
                  while($row=mysqli_fetch_array($query)){
                  $pre=$row['score'];
                          if($flag!=$pre){
                               $flag=$pre;
                              if($i!=1){
                                 $rank=$i;
                                      //echo "count<br />";
                                    }
                                $i++;
                               $rank = $rank;
                            }else{
                               $rank = $rank;
                            }
                $username = '"'.$row['username'].'"';
                $sql = mysqli_query($link,"UPDATE live_quiz_join SET rank = '$rank' WHERE username = '$username'");
                echo "<tr>
                <td>".$row['id']."</td>
                <td>".$row['username']."</td>
                <td>".$row['score']."</td>
                <td>".$row['rank']."</td>
                 <td>".$row['amount']."</td>
                 <td><a href='live_user_point_edit.php?quiz_id=".$id."&username=".$row['username']."'><button class='btn btn-primary'>Edit</button></a> <a href='live_user_answer.php?username=".$row['username']."&id=".$id."'><button class='btn btn-success'>Answer</button></td> 
         </tr>";

}
?>
                </tbody></table>
            </div>
                              
                              
                      </div>
                    </div>
                  
                    
                    </div>
               
                   
                </div>
         
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
     
      <!-- /.row -->
    </section>
    <!-- /.content -->
     

 
  <!-- /.content-wrapper -->

 <?php include 'side_bar.php';?>
  <!-- Control Sidebar -->
  <?php include 'footer.php';?>

  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<?php include 'common_js.php';?>
<!-- page script -->
<script>
$(document).ready(function() {

  $('#example1').DataTable( {
    responsive: true
} );
});
</script>
</body>
</html>
