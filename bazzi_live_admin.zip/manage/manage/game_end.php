<?php include 'session.php';?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Game Tournament</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
  include 'session.php';
  include  'nav_barr.php';
  include  'side_bar.php';?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>End Tournament</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">End Tournment</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
               <div class="row">
                    <?php if(isset($_COOKIE['tournament_add'])){
          
          echo '<div class="col-sm-6">'.$_COOKIE['tournament_add'].'</div>';
        }
        else {
            echo '<div class="col-sm-6">Tournament</div>';
        }
        ?>
                  
                
                  
                 </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive">
              <table id="tournament" class="table table-bordered table-hover" w>
                <thead>
                <tr>
                  <th>ID</th>
                 <th>Game Name </th>
                  <th>Icon</th>
                  <th>Join/Allow</th>
                  <th>Prize</th>
                  <th>Entry Fee</th>
                  <th>Play</th>
                  <th>End Date</th>
                  <th>Oparation</th>
                  
                </tr>
                </thead>
                <tbody>
                 <?php
                 extract($_REQUEST);
                  
                  
                  $str1="SELECT * FROM tbl_game_tournament WHERE status=3 AND t_status!=1";
                  $query=mysqli_query($link,$str1);
                 
                 
                while($row=mysqli_fetch_array($query)){
                  $text = "Payment Done";
                  $btn = "btn-success";
                  
                 echo "<tr>
                <td>".$row['id']."</td>
                <td>".$row['game_name']."</td>
                <td><img src='".$row['game_icon']."' alt='Smiley face' height='50' width='50'></td>
                <td>".$row['total_player']."/".$row['allow_player']."</td>
                
                <td>".$row['prize_pool']."</td>
                <td>".$row['entry_fee']."</td>
                <td><a href ='".$row['game_url']."'<button type='button' class='btn btn-success'>Play</button></a></td>
                <td>".$row['date']." ".$row['end_time']."</td>
                <td></a><a href='game_tournament_joined.php?id=".$row['id']."'><button type='button' class='btn btn-primary'>Join User</button></a> <a href='game_tournament_payment.php?id=".$row['id']."'><button type='button' class='btn btn-primary'>Give Point</button></a></td>
                
             </tr>
          ";
                  
                  
          
}
                    ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>ID</th>
                 <th>Game Name </th>
                  <th>Icon</th>
                  <th>Join/Allow</th>
                  <th>Prize</th>
                  <th>Entry Fee</th>
                  <th>Play</th>
                  <th>End Date</th>
                  <th>Oparation</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php include 'footer.php';?>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<?php include 'common_js.php';?>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    
  });
</script>


</body>
</html>
