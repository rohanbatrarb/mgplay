<?php
include 'db.php';
extract($_REQUEST);
$response = array();
$date = date("Y-m-d");
// Get List Host
if(@$upcoming_battle){
    $sql = mysqli_query($link,"SELECT * FROM tbl_host WHERE status='Upcoming'");
    $data = array();
    while($res=mysqli_fetch_assoc($sql)){
        $data[]=$res;
    }
    
    if($sql){
        $response['error']=false;
        $response['message']="Successfully Fetch Data";
        $response['data']=$data;
    }else {
        $response['error']=true;
        $response['message']="Something gone Wrong";
        
    }
    	print_r(json_encode($response));
    
}
if(@$ongoing_battle){
    $sql = mysqli_query($link,"SELECT * FROM tbl_host WHERE status='Ongoing' OR status='Upcoming'");
    $data = array();
    $i=0;
    while($res=mysqli_fetch_assoc($sql)){
        $id = $res['id'];
        $select = mysqli_query($link,"SELECT * FROM tbl_host_join WHERE username='$username' AND tbl_host='$id' ");
        $r = mysqli_num_rows($select);
        if($r>0){
            $data[]=$res;
            $i++;
        }
        
        
    }
    
    if($i>0){
        $response['error']=false;
        $response['message']="Successfully Fetch Data";
        $response['data']=$data;
    }else {
        $response['error']=true;
        $response['message']="Something gone Wrong";
        
    }
    	print_r(json_encode($response));
    
}
if(@$complete_battle){
    $sql = mysqli_query($link,"SELECT * FROM tbl_host WHERE status='Complete'");
    $data = array();
    $i=0;
    while($res=mysqli_fetch_assoc($sql)){
        $id = $res['id'];
        $select = mysqli_query($link,"SELECT * FROM tbl_host_join WHERE username='$username' AND tbl_host='$id' ");
        $r = mysqli_num_rows($select);
        if($r>0){
            $data[]=$res;
            $i++;
        }
    }
    
    if($i>0){
        $response['error']=false;
        $response['message']="Successfully Fetch Data";
        $response['data']=$data;
    }else {
        $response['error']=true;
        $response['message']="Something gone Wrong";
        
    }
    	print_r(json_encode($response));
    
}

///battle_leader

if($battle_leader){
    $sql = mysqli_query($link,"SELECT * FROM tbl_host_join WHERE tbl_host='$id' ORDER BY winning DESC");
   
    $data = array();
    while($res = mysqli_fetch_assoc($sql)){
        $data[]=$res;
    }
    if($sql){
        $response['error']=false;
        $response['message']="Successfully Fetch Data";
        $response['data']=$data;
    }else {
        $response['error']=true;
        $response['message']="Something gone Wrong";
        
    }
    print_r(json_encode($response));
}
//Get Details by Id
if($upcoming_details){
     $sql = mysqli_query($link,"SELECT * FROM tbl_host WHERE id ='$id'");
        $res = mysqli_fetch_assoc($sql);
    $user = mysqli_query($link,"SELECT * FROM tbl_host_join WHERE tbl_host ='$id' AND username='$username'");
    $r = mysqli_num_rows($user);
    if($sql){
        $response['error']=false;
        $response['status']=$r;
        $response['message']="Successfully Fetch Data";
        $response['data']=array($res);
    }else {
        $response['error']=true;
        $response['message']="Something gone Wrong";
        
    }
    	print_r(json_encode($response));
}
//Join Tournament

if($join_battle){
    
    $sql = mysqli_query($link,"SELECT points FROM users WHERE username='$username'");
    $res = mysqli_fetch_assoc($sql);
    if($res['points']<$entry_fee){
        $response['error']=true;
        $response['message']="Not Enough Coins to Your Wallet";
        print_r(json_encode($response));
        return false;
    }
    $check = mysqli_query($link,"SELECT username FROM tbl_host_join WHERE username='$username' AND tbl_host='$battle_id'");
    if(mysqli_num_rows($check)==1){
        $response['error']=true;
        $response['message']="Already Joined the Game";
        print_r(json_encode($response));
        return false;
    }
    $full = mysqli_query($link,"SELECT room_size,total_join, match_name FROM tbl_host WHERE id='$battle_id'");
    $f = mysqli_fetch_assoc($full);
    $name = $f['match_name'];
    if($f['room_size']==$f['total_join']) {
        $response['error']=true;
        $response['message']="Battle Full Try Another";
        print_r(json_encode($response));
        return false;
    }
   
    $join = mysqli_query($link,"INSERT INTO tbl_host_join SET username='$username',user_game ='$gamer_username',tbl_host ='$battle_id',entry_fee='$entry_fee',join_date='$date'");
    if($join) {
        $cut = mysqli_query($link,"UPDATE users SET points = points-'$entry_fee' WHERE username='$username'");
        $update = mysqli_query($link,"UPDATE tbl_host SET total_join=total_join+1 WHERE id ='$battle_id'");
        $tracker = mysqli_query($link,"INSERT INTO  tracker SET username='$username',points='$entry_fee',type='$name',date='$date'");
        $response['error']=false;
        $response['message']="Register Successfull";
        
    }else {
        $response['error']=true;
        $response['message']="Something Gone Wrong";
    }
    print_r(json_encode($response));
}

?>