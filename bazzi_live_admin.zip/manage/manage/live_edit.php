<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Live Quiz Edit</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 <script src="https://cdn.ckeditor.com/4.11.3/standard/ckeditor.js"></script>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
  include 'session.php';
  include  'nav_barr.php';
  
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Live Quiz Edit</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Live Quiz Edit</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Live Quiz Edit</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card-box">
                  
                  <h4 class="m-t-0 header-title"><b>Live Category Quiz</b></h4>
                  <p class="text-muted font-13 m-b-30">
                      Fill all necessary data to Update new match.
                  </p>
                  <?php extract($_REQUEST);
                  $sql = mysqli_query($link,"SELECT * FROM live_quiz_category WHERE id='$id'");
                  $res = mysqli_fetch_assoc($sql);
                  
                  ?>
                  <form action="update_live_quiz.php" data-parsley-validate novalidate enctype="multipart/form-data" method="post">
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="txtMtitle">Quiz Name*</label>
                          <input type="text" name="quiz_name" parsley-trigger="change" required placeholder="Enter match title" value="<?php echo $res['quiz_name'];?>" class="form-control" id="txtMtitle">
                          <input type="hidden" name="edit_category" value="1">
                          <input type="hidden" name="id" value="<?php echo $id;?>">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label for="txtMtitle">Sub Name*</label>
                         <input type="text" name="sub_name" parsley-trigger="change" required placeholder="Enter match title" value="<?php echo $res['sub_name'];?>" class="form-control" id="txtMtitle">
                        </div>
                      </div>
                       <div class="col-md-5">
                        <div class="form-group">
                          <label for="txtMtitle">Icon*</label>
                         <input type="text" name="icon" value="<?php echo $res['icon'];?>" class="form-control" >
                        </div>
                      </div>
                    </div>
                 
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="txtMtime">Entry Fee*</label>
                          <input id="txtMtime" name="entry_fee" type="number" value="<?php echo $res['entry_fee'];?>" placeholder="Entry Fee"required class="form-control">
                        </div>
                      </div>
                        <div class="col-md-4">
                        <div class="form-group">
                          <label for="txtMtime">Total Player*</label>
                          <input id="txtMtime" name="total_player" type="number" value="<?php echo $res['total_player'];?>" placeholder = "Total Player" required class="form-control">
                        </div>
                      </div>
                       <div class="col-md-4">
                        <div class="form-group">
                          <label for="txtMtime">Prize Pool*</label>
                          <input id="txtMtime" name="prize_pool" type="number" value="<?php echo $res['prize_pool'];?>" placeholder="Prize Pool"required class="form-control">
                        </div>
                      </div>
                     </div>
                    
                  <hr>
                  <div class="row">
                  <div class="col-md-4">
                        <div class="form-group">
                          <label for="txtMtitle">Status*</label>
                          <select class="form-control"  name="status" id="txtPlatform">
                            <?php 
                            $status =  $res['status'];
                          
                            if($status=="Draft"){
                                $ong = "selected";
                            }else if ($status=="Upcoming"){
                                $upc = "selected";
                            }else if ($status=="Payment"){
                                $pay = "selected";
                            }else if ($status=="Complete"){
                                $comp = "selected";
                            }
                            
                            echo '<option value="Draft" '.$ong.'>Draft</option>
                            <option value="Upcoming" '.$upc.'>Upcoming</option>
                            <option value="Payment" '.$pay.'>Payment</option>
                            <option value="Complete" '.$comp.'>Complete</option>';
                           
                            ?>
                            
                            
                          </select> 
                        </div>
                      </div>
                        <div class="col-md-4">
                        <div class="form-group">
                          <label for="txtMtime">Date*</label>
                          <input id="txtMtime" name="date" type="date" value="<?php echo $res['date'];?>" placeholder="Prize Pool"required class="form-control">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="txtMtime">Time*</label>
                          <input id="txtMtime" name="time" type="text" value="<?php echo $res['time'];?>" placeholder="24 Hour format"required class="form-control">
                        </div>
                      </div>
                     </div>
                   </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group text-right m-b-0">
                          <button class="btn btn-primary waves-effect waves-light" type="submit" name="btnSave" id="btnSave" > Save</button>
                          <!-- <a href="user-list.php" class="btn btn-default waves-effect waves-light m-l-5"> Cancel</a> -->
                         
                        </div>
                      </div>

                    </div>
                  </form>

                  
                </div>
              </div>
            </div>
                
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
     <?php include 'side_bar.php';?>
  

 
<!-- ./wrapper -->
<?php include 'footer.php';?>
<?php include 'common_js.php';?>
<!-- page script -->


</body>
</html>
