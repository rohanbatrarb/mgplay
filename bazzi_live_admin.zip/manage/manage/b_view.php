<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Details - Battle</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
   <link rel="stylesheet" href="plugins/custombox.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
  include 'session.php';
  include  'nav_barr.php';
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
           
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
            <?php extract($_REQUEST);
            
                $sql = mysqli_query($link,"SELECT * FROM tbl_host WHERE id='$id'");
                $res = mysqli_fetch_assoc($sql);
                ?>
                <div class="row">
                  <div class="col-md-8">
                      <div class="card-box">
                          Match Title:<h4 class="text-uppercase font-600"> <?php echo $res['match_name'];?></h4>
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="card-box">
                          Match Status:<h4 class="text-uppercase font-600"> <?php echo $res['status'];?></h4>
                      </div>
                  </div>
                  <div class="col-sm-12">
                    <div class="card-box widget-inline">
                      <div class="row">
                        <div class="col-lg-3 col-sm-6">
                          <div class="widget-inline-box text-center">
                            <h3><i class="text-primary md md-attach-money"></i> <b data-plugin="counterup">
                              <?php echo $res['winning_prize'];?>                             
                            </b></h3>
                            <h4 class="text-muted">Winning Prize</h4>
                          </div>
                        </div>
                        
                        <div class="col-lg-3 col-sm-6">
                          <div class="widget-inline-box text-center">
                            <h3><i class="text-custom md md-style"></i> <b data-plugin="counterup"><?php echo $res['per_kill'];?></b></h3>
                            <h4 class="text-muted">Prize/Kill</h4>
                          </div>
                        </div>
                        
                        <div class="col-lg-3 col-sm-6">
                          <div class="widget-inline-box text-center">
                            <h3><i class="text-pink md md-keyboard-tab"></i> <b data-plugin="counterup"><?php echo $res['entry_fee'];?></b></h3>
                            <h4 class="text-muted">Entry Fee</h4>
                          </div>
                        </div>
                        
                        <div class="col-lg-3 col-sm-6">
                          <div class="widget-inline-box text-center b-0">
                            <a href="b_join.php?id=<?php echo $id;?>"><h3><i class="text-purple md md-account-child"></i> <b data-plugin="counterup"><?php echo $res['total_join'];?></b></h3></a>
                            <a href="b_join.php?id=<?php echo $id;?>"><h4 class="text-muted">Total Participant</h4></a>
                          </div>
                        </div>
                        
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="row row-eq-height">
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                      <div class="card-box">
                          <h4 class="text-uppercase font-600">Match Details</h4>
                          <hr>
                          <p class="text-muted font-13 m-b-30">
                              <p class="text-muted"><strong>Time :</strong> <span class="m-l-15"><?php echo $res['game_date']. $res['game_time'];?></span></p>
                              <p class="text-muted"><strong>Version :</strong> <span class="m-l-15"><?php echo $res['version'];?></span></p>
                              <p class="text-muted"><strong>Map :</strong> <span class="m-l-15"><?php echo $res['map'];?></span></p>
                              
                      </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                      <div class="card-box">
                          <h4 class="text-uppercase font-600">Room Details </h4>
                          <hr>
                          <p class="text-muted font-13 m-b-30">
                              <p class="text-muted"><strong>Room ID :</strong> <span class="m-l-15"><?php echo $res['room_id'];?></span></p>
                              <p class="text-muted"><strong>Room Password :</strong> <span class="m-l-15"><?php echo $res['room_pass'];?></span></p>
                              <p class="text-muted"><strong>Room Status :</strong> <span class="m-l-15"><?php echo $res['room_status'];?></span></p>
                              <p class="text-muted"><strong>Room Size :</strong> <span class="m-l-15"><?php echo $res['room_size'];?></span></p>
                          </p>
                      </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                      <div class="card-box">
                          <h4 class="text-uppercase font-600">Other Details</h4>
                          <hr>
                          <p class="text-muted font-13 m-b-30">
                              <p class="text-muted"><strong>Match Type :</strong> <span class="m-l-15"><?php echo $res['match_type'];?></span></p>
                              <p class="text-muted"><strong>Entry Type :</strong> <span class="m-l-15">Paid</span></p>
                              <p class="text-muted"><strong>Sponsored By :</strong> <span class="m-l-15"></span></p>
                              <p class="text-muted"><strong>Created On :</strong> <span class="m-l-15"><?php echo $res['create_date'];?></span></p>
                          </p>
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <div class="card-box">
                          <img src="<?php echo $res['cover'];?>" />
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <div class="card-box">
                          <h4 class="text-uppercase font-600">Spectate Video</h4>
                          <hr>
                          <p class="text-muted font-13 m-b-30">
                              <iframe id="video" width="440" height="135" src="<?php echo $res['video'];?>" frameborder="0" allowfullscreen></iframe>
                          </p>
                      </div>
                    </div>
                    <!-- <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <div class="card-box">
                          <h4 class="text-uppercase font-600">Banner Image</h4>
                          <hr>
                          <p class="text-muted font-13 m-b-30">
                              <img src="" />
                          </p>
                      </div>
                    </div> -->
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="card-box">
                          <h4 class="text-uppercase font-600">Match Rules</h4>
                          <hr>
                          <p class="text-muted font-13 m-b-30"><?php echo $res['rules'];?></p>
                      </div>
                    </div>
                   
                </div>
         
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
     <?php include 'side_bar.php';?>
  </div>
 
  <!-- /.content-wrapper -->


  <!-- Control Sidebar -->
 
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
 <?php include 'footer.php';?>
<?php include 'common_js.php';?>
<!-- page script -->

</body>
</html>
