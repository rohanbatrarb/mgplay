<?php

		$servername = 'localhost';
        $username = 'gamebazz_quick';
        $password = '957582359@1';
        $dbname = 'gamebazz_quick';
        // Create connection
		//trigger exception in a "try" block
		try {
		  $conn = mysqli_connect($servername, $username, $password, $dbname);
		  echo "Connection Successful.";
		}
		//catch exception
		catch(Exception $e) {
		  echo 'Message: ' .$e->getMessage();
		}
		
?>