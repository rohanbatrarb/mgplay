<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Add Question</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 <script src="https://cdn.ckeditor.com/4.11.3/standard/ckeditor.js"></script>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
  include 'session.php';
  include  'nav_barr.php';
  extract($_REQUEST);
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Question</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Question</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Add Question</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card-box">
                  
                  <h4 class="m-t-0 header-title"><b>Question</b></h4>
                  <p class="text-muted font-13 m-b-30">
                      Fill all necessary data to Update new match.
                  </p>
                 
                  <form action="update_live_quiz.php" data-parsley-validate novalidate enctype="multipart/form-data" method="post">
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="txtMtitle">Question*</label>
                          <input type="text" name="question" parsley-trigger="change" required placeholder="Enter match title"  class="form-control" id="txtMtitle">
                          <input type="hidden" name="add_question" value="<?php echo $category;?>">
                        
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="txtMtitle">Correct*</label>
                          <select class="form-control"  name="correct" id="txtPlatform">
                            
                            
                            <option value="1">Option 1</option>
                            <option value="2" >Option 2</option>
                         
                             <option value="3">Option 3</option>
                            <option value="4" >Option 4</option>
                            
                          </select> 
                        </div>
                      </div>
                    </div>
                 
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group">
                          <label for="txtMtime">Option 1*</label>
                          <input id="txtMtime" name="opt_one" type="text" placeholder="Opt 1"required class="form-control">
                        </div>
                      </div>
                        <div class="col-md-3">
                        <div class="form-group">
                          <label for="txtMtime">Option 2*</label>
                          <input id="txtMtime" name="opt_two" type="text" placeholder = "Opt 2" required class="form-control">
                        </div>

                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label for="txtMtime">Option 3*</label>
                          <input id="txtMtime" name="opt_three" type="text" placeholder = "Opt 3" required class="form-control">
                        </div>
                      </div>
                        <div class="col-md-3">
                        <div class="form-group">
                          <label for="txtMtime">Option 4*</label>
                          <input id="txtMtime" name="opt_four" type="text" placeholder = "Opt 4" required class="form-control">
                        </div>
                      </div>
                      
                    </div>
                    
                
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group text-right m-b-0">
                          <button class="btn btn-primary waves-effect waves-light" type="submit" name="btnSave" id="btnSave" > Save</button>
                          <!-- <a href="user-list.php" class="btn btn-default waves-effect waves-light m-l-5"> Cancel</a> -->
                         
                        </div>
                      </div>

                    </div>
                  </form>

                  
                </div>
              </div>
            </div>
                
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
     <?php include 'side_bar.php';?>
  

 
<!-- ./wrapper -->
<?php include 'footer.php';?>
<?php include 'common_js.php';?>
<!-- page script -->


</body>
</html>
