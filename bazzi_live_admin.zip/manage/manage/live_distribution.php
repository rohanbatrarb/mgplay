<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Live Distribution</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
  include 'session.php';
  include  'nav_barr.php';
  extract($_REQUEST);
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Live Ditribution</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="sm col-6">
                        <h3 class="card-title">Distribution</h3>
                    </div>
                     <div class="sm col-6 text-right">
                       <a href="live_distribution_add.php?distribution=<?php echo $id;?>"><button class="btn btn-primary">+ Add</button></a>
                    </div>
                </div>
              
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive">
                <table id="example1" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>S.No.</th>
                 <th>Rank</th>
                  <th>Amount</th>
                 <th></th>
               
                </tr>
                </thead><tbody> 
                
                
                <?php 
               $str="SELECT * FROM live_quiz_distribution WHERE quiz_id='$id'";
                $query=mysqli_query($link,$str);
                  $i = 1;
                  while($row=mysqli_fetch_array($query)){
                   
                    
                   
                
                echo "<tr>
                <td>".$i."</td>
                <td>".$row['rank']."</td>
                <td>".$row['amount']."</td>
                <td><a href='live_distribution_edit.php?distribution=$id&id=".$row['id']."'><button class='btn btn-success'>Edit</button></a></td> 
         </tr>";
$i++;
}
?>
                </tbody></table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include 'side_bar.php';?>
  <!-- /.content-wrapper -->
 <?php include 'footer.php';?>

  <!-- Control Sidebar -->
 
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<?php include 'common_js.php';?>
<!-- page script -->
<script>
$(document).ready(function() {

  $('#example1').DataTable( {
    responsive: true
} );
});
</script>
</body>
</html>
