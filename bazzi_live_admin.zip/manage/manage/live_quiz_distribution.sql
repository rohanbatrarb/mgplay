-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 19, 2020 at 08:04 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u822810583_baazi`
--

-- --------------------------------------------------------

--
-- Table structure for table `live_quiz_distribution`
--

CREATE TABLE `live_quiz_distribution` (
  `id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `rank` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `live_quiz_distribution`
--

INSERT INTO `live_quiz_distribution` (`id`, `quiz_id`, `rank`, `amount`) VALUES
(1, 62, '1', 100),
(2, 2, '2', 50),
(3, 3, '1', 10),
(4, 4, '3', 25),
(5, 6, '0', 11),
(6, 8, '', 25),
(7, 10, '', 20),
(8, 9, '1', 20),
(9, 18, '1-10', 100),
(10, 18, '11-20', 50),
(11, 18, '21-100', 25),
(12, 21, '1-10', 12),
(13, 21, '11-20', 10),
(14, 22, '1-10', 15),
(15, 23, '1-10', 30),
(16, 23, '11-30', 25),
(17, 28, '1-10', 35),
(18, 28, '11-30', 25),
(19, 29, '1-10', 11),
(20, 30, '1-10', 28),
(21, 30, '11-20', 22),
(22, 33, '1-10', 40),
(23, 33, '11-30', 30),
(24, 35, '1-10', 35),
(25, 37, '1-30', 35),
(26, 39, '1-8', 10),
(27, 42, '1-20', 25),
(28, 44, '1-5', 20),
(29, 44, '6-15', 11),
(30, 44, '16-20', 10),
(31, 48, '1-10', 15),
(32, 49, '1-10', 30),
(33, 49, '11-20', 20),
(34, 50, '1-10', 18),
(35, 50, '11-30', 12),
(36, 53, '1-10', 35),
(37, 53, '11-30', 25),
(38, 54, '1-10', 14),
(39, 54, '11-20', 11),
(40, 55, '1-100', 11),
(41, 56, '1-10', 30),
(42, 57, '1', 35),
(43, 57, '2-8', 21),
(44, 60, '1-10', 30),
(45, 60, '11-20', 20);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `live_quiz_distribution`
--
ALTER TABLE `live_quiz_distribution`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `live_quiz_distribution`
--
ALTER TABLE `live_quiz_distribution`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
