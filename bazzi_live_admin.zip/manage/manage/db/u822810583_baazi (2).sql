-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 19, 2020 at 08:25 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u822810583_baazi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(56) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company_name` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `upi_id` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `upi_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `name`, `email`, `company_name`, `last_update`, `upi_id`, `upi_name`) VALUES
(1, 'admin', '2532c3184b3cfec912e247926bd546a5', 'Mohsin Jawwad', 'mohsinjawed359@gmail.com', 'Baazi Live', '2020-07-16 03:42:02', '8172967999@paytm', 'Mohsin Jawwad');

-- --------------------------------------------------------

--
-- Table structure for table `admob`
--

CREATE TABLE `admob` (
  `id` int(11) NOT NULL,
  `banner` varchar(200) NOT NULL,
  `full` varchar(200) NOT NULL,
  `reward` varchar(200) NOT NULL,
  `ads_id` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `img_url` varchar(255) NOT NULL,
  `link_url` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `rotation` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `draw_result`
--

CREATE TABLE `draw_result` (
  `id` int(10) NOT NULL,
  `game_name` varchar(255) NOT NULL DEFAULT '0',
  `user_email` varchar(255) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '0',
  `points` varchar(255) NOT NULL DEFAULT '0',
  `game_prize` varchar(255) NOT NULL DEFAULT '0',
  `type` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `game_list`
--

CREATE TABLE `game_list` (
  `id` int(10) NOT NULL,
  `paid_game` varchar(20) NOT NULL,
  `game_url` varchar(500) NOT NULL,
  `game_icon` varchar(500) NOT NULL,
  `join_fee` varchar(200) NOT NULL,
  `free` varchar(200) NOT NULL,
  `paid` varchar(200) NOT NULL,
  `background` varchar(500) NOT NULL,
  `rotation` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game_list`
--

INSERT INTO `game_list` (`id`, `paid_game`, `game_url`, `game_icon`, `join_fee`, `free`, `paid`, `background`, `rotation`) VALUES
(1, 'Tower Build', 'https://wpwala.com/nostragumus/spin/game/tower/', 'http://wpwala.com/nostragumus/upcoming/images/tower_logo.png', '1', '5', '7', 'http://wpwala.com/nostragumus/upcoming/images/game_holder.png', 2);

-- --------------------------------------------------------

--
-- Table structure for table `live_quiz_category`
--

CREATE TABLE `live_quiz_category` (
  `id` int(11) NOT NULL,
  `quiz_name` varchar(500) NOT NULL,
  `sub_name` varchar(500) NOT NULL,
  `total_question` int(11) NOT NULL,
  `entry_fee` int(11) NOT NULL,
  `prize_pool` int(11) NOT NULL,
  `total_player` int(11) NOT NULL,
  `total_join` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(255) NOT NULL,
  `entry_date` date NOT NULL,
  `status` varchar(255) NOT NULL,
  `tbL_status` int(11) NOT NULL,
  `icon` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `live_quiz_category`
--

INSERT INTO `live_quiz_category` (`id`, `quiz_name`, `sub_name`, `total_question`, `entry_fee`, `prize_pool`, `total_player`, `total_join`, `date`, `time`, `entry_date`, `status`, `tbL_status`, `icon`) VALUES
(1, 'Sports', 'Top 20 Wins', 3, 10, 450, 50, 2, '2020-06-22', '20:00:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(2, 'General Knowledge', 'Everyone Wins', 2, 20, 2100, 100, 0, '2020-06-23', '20:00:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(3, 'Bollywood', 'Top 50 Wins', 1, 20, 1000, 60, 1, '2020-06-24', '20:00:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(4, 'Sports', 'Top 30 Wins', 0, 10, 350, 40, 1, '2020-06-27', '12:00:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(5, 'General Knowledge', 'Top 20 Wins', 0, 10, 200, 25, 0, '2020-06-28', '20:00:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(6, 'Bollywood', 'Top 50 Wins', 0, 10, 500, 60, 0, '2020-06-29', '20:00:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(7, 'English', 'Everyone Wins', 0, 10, 1100, 100, 0, '2020-06-30', '20:00:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(8, 'Sports', 'Top 30 Wins', 0, 20, 700, 40, 0, '2020-07-06', '12:00:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(9, 'Bollywood', 'Free Quiz', 0, 0, 0, 100, 1, '2020-07-06', '20:00:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(10, 'Bollywood', 'Top 80 Wins', 0, 10, 800, 100, 0, '2020-07-07', '12:00:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(11, 'Chidiya Udd', 'Everyone Wins', 0, 100, 11000, 100, 0, '2020-07-08', '12:00:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(12, 'Sports', 'Everyone Wins', 3, 50, 6000, 100, 1, '2020-07-16', '09:48:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(13, 'Bollywood', 'Everyone Wins', 3, 20, 2500, 100, 0, '2020-07-19', '12:00:00', '0000-00-00', 'Payment', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(14, 'Chidiya Udd', 'Everyone Wins', 3, 40, 4500, 100, 0, '2020-07-20', '20:00:00', '0000-00-00', 'Upcoming', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(15, 'English', 'Everyone Wins', 3, 100, 1100, 100, 0, '2020-07-21', '20:00:00', '0000-00-00', 'Upcoming', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(16, 'Sports', 'Everyone Wins', 1, 10, 3000, 200, 0, '2020-07-22', '20:00:00', '0000-00-00', 'Upcoming', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png'),
(17, 'Bollywood', 'Free Quiz', 0, 0, 0, 1000, 0, '2020-07-23', '12:00:00', '0000-00-00', 'Upcoming', 0, 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/71/72/af/7172af67-e9c4-4c2c-054f-d765761f31ba/source/175x175-75.png');

-- --------------------------------------------------------

--
-- Table structure for table `live_quiz_distribution`
--

CREATE TABLE `live_quiz_distribution` (
  `id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `rank` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `live_quiz_distribution`
--

INSERT INTO `live_quiz_distribution` (`id`, `quiz_id`, `rank`, `amount`) VALUES
(1, 1, '1-10', 25),
(2, 1, '11-20', 20),
(3, 2, '1-100', 21),
(4, 3, '1-10', 30),
(5, 3, '11-50', 25),
(6, 12, '1-50', 55);

-- --------------------------------------------------------

--
-- Table structure for table `live_quiz_join`
--

CREATE TABLE `live_quiz_join` (
  `id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `entry_date` date NOT NULL,
  `score` int(11) NOT NULL DEFAULT 0,
  `rank` int(11) NOT NULL DEFAULT 0,
  `amount` int(11) NOT NULL DEFAULT 0,
  `tbl_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `live_quiz_join`
--

INSERT INTO `live_quiz_join` (`id`, `quiz_id`, `username`, `entry_date`, `score`, `rank`, `amount`, `tbl_status`) VALUES
(1, 1, 'mohsin359', '2020-06-19', 0, 2, 0, 0),
(2, 1, 'hasan', '2020-06-21', 320, 1, 25, 1),
(3, 3, 'hasan', '2020-06-24', 106, 1, 0, 1),
(4, 4, 'mohsin359', '2020-06-25', 0, 2, 0, 0),
(5, 9, 'mohsin359', '2020-07-04', 0, 2, 0, 0),
(6, 12, 'hasan', '2020-07-16', 318, 1, 55, 1);

-- --------------------------------------------------------

--
-- Table structure for table `live_quiz_question`
--

CREATE TABLE `live_quiz_question` (
  `id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `question` varchar(500) NOT NULL,
  `opt_one` varchar(500) NOT NULL,
  `opt_two` varchar(500) NOT NULL,
  `opt_three` varchar(255) NOT NULL,
  `opt_four` varchar(255) NOT NULL,
  `correct` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `live_quiz_question`
--

INSERT INTO `live_quiz_question` (`id`, `quiz_id`, `question`, `opt_one`, `opt_two`, `opt_three`, `opt_four`, `correct`) VALUES
(1, 1, 'Cricket World Cup 1983 Winner Nation?', 'India', 'Pakistan', 'England', 'Australia', 1),
(2, 1, 'Present Captain of New Zealand Cricket Team', 'Mark Butcher', 'Ross Taylor', 'Kane Williamson', 'Tim Southee', 3),
(3, 1, 'Which Nation Won Aisa Cup Cricket 2010?', 'Srilanka', 'Pakistan', 'India', 'Bangladesh', 2),
(4, 2, 'Cricket World Cup 2003 Winner Nation?', 'India', 'Pakistan', 'Australia', 'Bangladesh', 3),
(5, 2, 'Present Captain of New Zealand Cricket Team', 'Mark Butcher', 'Ross Taylor', 'Kane Williamson', 'Tim Southee', 3),
(6, 3, 'Cricket World Cup 1983 Winner Nation?', 'India', 'Pakistan', 'England', 'Australia', 1),
(7, 0, 'Which is the largest planet in our Solar system?', 'Mercury', 'Earth', 'Jupiter', 'Pluto', 3),
(8, 0, 'Which month of the year has the least number of days?', 'January', 'February', 'March', 'April', 2),
(9, 0, 'What is the capital of India?', 'Delhi', 'Mumbai', 'Kolkata', 'Lucknow', 1),
(10, 0, 'How many continents are there in the world?', '5 Continents', '6 Continents', '7 Continents', '8 Continents', 3),
(11, 0, 'Which bird lays the largest eggs?', 'Duck', 'Owl', 'Pigeon', 'Ostrich', 4),
(12, 12, 'World Cup 1983 Winner Nation? (विश्व कप 1983 विजेता राष्ट्र?)', 'India (भारत)', 'Pakistan (पाकिस्तान)', 'Australia (ऑस्ट्रेलिया)', 'West Indies (वेस्ट इंडीज)', 1),
(13, 12, 'Present Captain of Indian Cricket Team? (भारतीय क्रिकेट टीम के वर्तमान कप्तान?)', 'MS Dhoni (महेंद्र सिंह धोनी)', 'Virat Kohli (विराट कोहली)', 'Rohit Sharma (रोहित शर्मा)', 'Shikhar Dhawan (शिखर धवन)', 2),
(14, 12, 'World Cup 2011 Winner Nation? (विश्व कप 2011 विजेता राष्ट्र?)', 'West Indies (वेस्ट इंडीज)', 'Pakistan (पाकिस्तान)', 'India (भारत)', 'Australia (ऑस्ट्रेलिया)', 3),
(15, 13, 'Cricket World Cup 1983 Winner Nation?', 'India', 'Pakistan', 'England', 'Australia', 1),
(16, 13, 'Present Captain of New Zealand Cricket Team', 'Mark Butcher', 'Ross Taylor', 'Kane Williamson', 'Tim Southee', 3),
(17, 13, 'Which Nation Won Aisa Cup Cricket 2010?', 'India', 'Pakistan', 'Sri Lanka', 'Bangladesh', 2),
(18, 14, 'Cricket World Cup 1983 Winner Nation?', 'India', 'Pakistan', 'England', 'Australia', 1),
(19, 14, 'Present Captain of New Zealand Cricket Team', 'Mark Butcher', 'Ross Taylor', 'Kane Williamson', 'Tim Southee', 3),
(20, 14, 'Which Nation Won Aisa Cup Cricket 2010?', 'India', 'Pakistan', 'Sri Lanka', 'Bangladesh', 2),
(21, 15, 'Cricket World Cup 1983 Winner Nation?', 'India', 'Pakistan', 'England', 'Australia', 1),
(22, 15, 'Present Captain of New Zealand Cricket Team', 'Mark Butcher', 'Ross Taylor', 'Kane Williamson', 'Tim Southee', 3),
(23, 15, 'Which Nation Won Aisa Cup Cricket 2010?', 'India', 'Pakistan', 'Sri Lanka', 'Bangladesh', 2),
(24, 16, 'Cricket World Cup 1983 Winner Nation?', 'India', 'Pakistan', 'England', 'Australia', 1);

-- --------------------------------------------------------

--
-- Table structure for table `live_quiz_user_answer`
--

CREATE TABLE `live_quiz_user_answer` (
  `id` int(11) NOT NULL,
  `username` varchar(500) NOT NULL,
  `tbl_quiz` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `left_time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `live_quiz_user_answer`
--

INSERT INTO `live_quiz_user_answer` (`id`, `username`, `tbl_quiz`, `question_id`, `answer`, `score`, `left_time`) VALUES
(1, 'hasan', 0, 7, 2, 0, 0),
(2, 'hasan', 0, 8, 3, 0, 0),
(3, 'hasan', 0, 9, 1, 100, 7),
(4, 'hasan', 0, 10, 3, 100, 8),
(5, 'hasan', 0, 11, 4, 100, 8),
(6, 'trustonsahil@gmail.com', 0, 7, 1, 0, 0),
(7, 'trustonsahil@gmail.com', 0, 8, 1, 0, 0),
(8, 'trustonsahil@gmail.com', 0, 9, 2, 0, 0),
(9, 'trustonsahil@gmail.com', 0, 10, 1, 0, 0),
(10, 'trustonsahil@gmail.com', 0, 11, 2, 0, 0),
(11, 'MehdiDz', 0, 7, 3, 100, 7),
(12, 'MehdiDz', 0, 8, 0, 0, 0),
(13, 'MehdiDz', 0, 9, 0, 0, 0),
(14, 'MehdiDz', 0, 10, 0, 0, 0),
(15, 'MehdiDz', 0, 11, 0, 0, 0),
(16, 'BiBelgium', 0, 7, 1, 0, 0),
(17, 'BiBelgium', 0, 8, 1, 0, 0),
(18, 'BiBelgium', 0, 10, 1, 0, 0),
(19, 'BiBelgium', 0, 11, 1, 0, 0),
(20, 'aaa111', 0, 7, 1, 0, 0),
(21, 'aaa111', 0, 8, 2, 100, 9),
(22, 'aaa111', 0, 9, 2, 0, 0),
(23, 'aaa111', 0, 10, 3, 100, 8),
(24, 'aaa111', 0, 11, 4, 100, 6),
(25, 'kunalsahu', 0, 7, 1, 0, 0),
(26, 'kunalsahu', 0, 8, 2, 100, 4),
(27, 'kunalsahu', 0, 9, 1, 100, 7),
(28, 'kunalsahu', 0, 10, 1, 0, 0),
(29, 'kunalsahu', 0, 11, 1, 0, 0),
(30, 'muhammaduzair', 0, 7, 3, 100, 4),
(31, 'muhammaduzair', 0, 8, 2, 100, 6),
(32, 'muhammaduzair', 0, 9, 1, 100, 7),
(33, 'muhammaduzair', 0, 10, 3, 100, 6),
(34, 'muhammaduzair', 0, 11, 4, 100, 5),
(35, 'dk infotech', 0, 7, 2, 0, 0),
(36, 'dk infotech', 0, 8, 1, 0, 0),
(37, 'dk infotech', 0, 9, 1, 100, 7),
(38, 'dk infotech', 0, 10, 1, 0, 0),
(39, 'dk infotech', 0, 11, 4, 100, 1),
(40, 'hasan', 1, 1, 1, 100, 6),
(41, 'hasan', 1, 2, 3, 100, 7),
(42, 'hasan', 1, 3, 2, 100, 7),
(43, 'mohsin359', 0, 7, 2, 0, 0),
(44, 'mohsin359', 0, 8, 3, 0, 0),
(45, 'mohsin359', 0, 9, 1, 100, 8),
(46, 'mohsin359', 0, 10, 3, 100, 9),
(47, 'mohsin359', 0, 11, 4, 100, 8),
(48, 'adiikakkar', 0, 7, 2, 0, 0),
(49, 'adiikakkar', 0, 8, 2, 100, 8),
(50, 'adiikakkar', 0, 9, 1, 100, 8),
(51, 'adiikakkar', 0, 10, 4, 0, 0),
(52, 'adiikakkar', 0, 11, 1, 0, 0),
(53, 'Farez', 0, 7, 4, 0, 0),
(54, 'Farez', 0, 8, 0, 0, 0),
(55, 'Farez', 0, 9, 0, 0, 0),
(56, 'Farez', 0, 10, 0, 0, 0),
(57, 'ayush', 0, 7, 3, 100, 3),
(58, 'ayush', 0, 8, 2, 100, 5),
(59, 'ayush', 0, 9, 1, 100, 7),
(60, 'ayush', 0, 10, 3, 100, 2),
(61, 'ayush', 0, 11, 4, 100, 7),
(62, 'hasan', 3, 6, 1, 100, 6),
(63, 'hasan', 12, 12, 1, 100, 6),
(64, 'hasan', 12, 13, 2, 100, 5),
(65, 'hasan', 12, 14, 3, 100, 7),
(66, 'kapil03', 0, 7, 3, 100, 2),
(67, 'kapil03', 0, 8, 3, 0, 0),
(68, 'kapil03', 0, 9, 2, 0, 0),
(69, 'kapil03', 0, 10, 3, 100, 9),
(70, 'kapil03', 0, 11, 2, 0, 0),
(71, 'AlphaM', 0, 7, 2, 0, 0),
(72, 'AlphaM', 0, 8, 2, 100, 6),
(73, 'AlphaM', 0, 9, 2, 0, 0),
(74, 'AlphaM', 0, 10, 2, 0, 0),
(75, 'AlphaM', 0, 11, 2, 0, 0),
(76, 'manzoor', 0, 7, 3, 100, 6),
(77, 'manzoor', 0, 8, 2, 100, 7),
(78, 'manzoor', 0, 9, 1, 100, 8),
(79, 'manzoor', 0, 10, 3, 100, 8),
(80, 'manzoor', 0, 11, 4, 100, 8);

-- --------------------------------------------------------

--
-- Table structure for table `lucky_draw`
--

CREATE TABLE `lucky_draw` (
  `id` int(100) NOT NULL,
  `lucky_draw_name` varchar(20) NOT NULL,
  `prize` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `total_user` varchar(255) NOT NULL DEFAULT '0',
  `date_result` date NOT NULL,
  `total_allow_user` varchar(255) NOT NULL,
  `draw_fee` varchar(10) NOT NULL,
  `winner_email` varchar(200) NOT NULL,
  `end_time` time NOT NULL,
  `img` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lucky_draw`
--

INSERT INTO `lucky_draw` (`id`, `lucky_draw_name`, `prize`, `status`, `total_user`, `date_result`, `total_allow_user`, `draw_fee`, `winner_email`, `end_time`, `img`) VALUES
(1, 'Lucky Money', '1000', '0', '22', '2020-08-30', '120', '10', '', '12:00:00', 'http://baazilive.in/manage/dist/img/logo.png'),
(2, 'Lucky Money', '5000', '', '0', '2020-08-20', '600', '10', '', '20:00:00', 'http://baazilive.in/manage/dist/img/logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `my_contests`
--

CREATE TABLE `my_contests` (
  `id` int(255) NOT NULL,
  `game_id_name` varchar(1000) NOT NULL,
  `game_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `game_email` varchar(255) NOT NULL,
  `game_win_status` varchar(255) NOT NULL DEFAULT '0',
  `game_result_date` varchar(255) NOT NULL,
  `game_prize` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `my_contests`
--

INSERT INTO `my_contests` (`id`, `game_id_name`, `game_name`, `username`, `game_email`, `game_win_status`, `game_result_date`, `game_prize`) VALUES
(1, '1', 'Lucky Money', 'mohsin359', 'mohsinjawed359@gmail.com', '0', '2020-07-10', '1000'),
(2, '1', 'Lucky Money', 'mohsin359', 'mohsinjawed359@gmail.com', '0', '2020-07-10', '1000'),
(3, '1', 'Lucky Money', 'mohsin359', 'mohsinjawed359@gmail.com', '0', '2020-07-10', '1000'),
(4, '1', 'Lucky Money', 'BiBelgium', 'gantsetseg2017@gmail.com', '0', '2020-07-10', '1000'),
(5, '1', 'Lucky Money', 'adiikakkar', 'adityakukkar444a@gmail.com', '0', '2020-07-10', '1000'),
(6, '1', 'Lucky Money', 'mohsin359', 'mohsinjawed359@gmail.com', '0', '2020-07-10', '1000'),
(7, '1', 'Lucky Money', 'mohsin359', 'mohsinjawed359@gmail.com', '0', '2020-07-10', '1000'),
(8, '1', 'Lucky Money', 'mohsin359', 'mohsinjawed359@gmail.com', '0', '2020-07-10', '1000'),
(9, '1', 'Lucky Money', 'adiikakkar', 'adityakukkar444a@gmail.com', '0', '2020-07-10', '1000'),
(10, '1', 'Lucky Money', 'devshukla', 'devshukla@gmail.com', '0', '2020-07-10', '1000'),
(11, '1', 'Lucky Money', 'devshukla', 'devshukla@gmail.com', '0', '2020-07-10', '1000'),
(12, '1', 'Lucky Money', 'devshukla', 'devshukla@gmail.com', '0', '2020-07-10', '1000'),
(13, '1', 'Lucky Money', 'devshukla', 'devshukla@gmail.com', '0', '2020-07-10', '1000'),
(14, '1', 'Lucky Money', 'devshukla', 'devshukla@gmail.com', '0', '2020-07-10', '1000'),
(15, '1', 'Lucky Money', 'devshukla', 'devshukla@gmail.com', '0', '2020-07-10', '1000'),
(16, '1', 'Lucky Money', 'devshukla', 'devshukla@gmail.com', '0', '2020-07-10', '1000'),
(17, '1', 'Lucky Money', 'devshukla', 'devshukla@gmail.com', '0', '2020-07-10', '1000'),
(18, '1', 'Lucky Money', 'devshukla', 'devshukla@gmail.com', '0', '2020-07-10', '1000'),
(19, '1', 'Lucky Money', 'devshukla', 'devshukla@gmail.com', '0', '2020-07-10', '1000'),
(20, '1', 'Lucky Money', 'devshukla', 'devshukla@gmail.com', '0', '2020-07-10', '1000'),
(21, '1', 'Lucky Money', 'mohsin359', 'mohsinjawed359@gmail.com', '0', '2020-07-10', '1000'),
(22, '1', 'Lucky Money', 'hasan', 'mohsinjawwad359@gmail.com', '0', '2020-08-30', '1000');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `message` varchar(512) NOT NULL,
  `image` varchar(256) NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment_requests`
--

CREATE TABLE `payment_requests` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `request_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `request_amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `points_used` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remarks` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `txn` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment_requests`
--

INSERT INTO `payment_requests` (`id`, `username`, `payment_address`, `request_type`, `request_amount`, `points_used`, `remarks`, `status`, `date`, `txn`) VALUES
(1, 'mohsin359', '9517193081', 'PAYTM', '5762', '5762', 'ID : 1 requested for payment', 1, '2020-06-25', ''),
(2, 'mohsin359', '8318036382', 'PAYTM', '1701', '1701', 'ID : 1 requested for payment', 1, '2020-06-26', ''),
(3, 'mohsin359', '8318036382', 'PAYTM', '2200', '2200', 'ID : 1 requested for payment', 1, '2020-06-26', ''),
(4, 'mohsin359', '8172967999', 'PAYTM', '1800', '1800', 'ID : 1 requested for payment', 1, '2020-06-26', ''),
(5, 'mohsin359', '8172967999', 'PAYTM', '1500', '1500', 'ID : 1 requested for payment', 1, '2020-06-27', ''),
(6, 'mohsin359', '8318036382', 'PAYTM', '1500', '1500', 'ID : 1 requested for payment', 1, '2020-06-27', ''),
(8, 'Vicky7193', '12', 'PAYTM', '4000', '4000', 'ID : 3 requested for payment', 1, '2020-06-29', ''),
(7, 'mohsin359', '8318036382', 'PAYTM', '500', '500', 'ID : 1 requested for payment', 1, '2020-06-27', ''),
(9, 'Vicky7193', '12', 'PAYTM', '4000', '4000', 'ID : 3 requested for payment', 1, '2020-06-29', ''),
(10, 'Vicky7193', '12', 'PAYTM', '4000', '4000', 'ID : 3 requested for payment', 1, '2020-06-29', ''),
(11, 'mohsin359', '8318036382', 'PAYTM', '554', '554', 'ID : 1 requested for payment', 1, '2020-06-30', ''),
(12, 'mohsin359', 'Bank Name :  Account Number :  IFSC :  Holder Name : ', '10', '10', '10', 'ID : 1 requested for payment', 1, '2020-07-15', ''),
(13, 'mohsin359', '7049637244', '1', '1', '1', 'ID : 1 requested for payment', 1, '2020-07-15', ''),
(14, 'mohsin359', 'fd', '10', '10', '10', 'ID : 1 requested for payment', 1, '2020-07-15', ''),
(15, 'mohsin359', '', 'Bank', '10', '10', 'ID : 1 requested for payment', 1, '2020-07-15', ''),
(16, 'mohsin359', 'Bank Name : fdas Account Number : 15552 IFSC : fdas Holder Name : fdsafa', 'Bank', '10', '10', 'ID : 1 requested for payment', 0, '2020-07-16', ''),
(17, 'hasan', 'Bank Name : Bank of Baroda Account Number : 506401845123 IFSC : BARB0ARDESH Holder Name : Mohsin Jawwad', 'Bank', '500', '500', 'ID : 2 requested for payment', 1, '2020-07-16', '');

-- --------------------------------------------------------

--
-- Table structure for table `pollfish`
--

CREATE TABLE `pollfish` (
  `id` int(11) NOT NULL,
  `device_id` varchar(255) NOT NULL,
  `cpa` varchar(255) NOT NULL,
  `request_uuid` varchar(255) NOT NULL,
  `timestamp` varchar(255) NOT NULL,
  `tx_id` varchar(255) NOT NULL,
  `signature` varchar(255) NOT NULL,
  `reward_name` varchar(255) NOT NULL,
  `reward_value` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_all_joined_question`
--

CREATE TABLE `tbl_all_joined_question` (
  `id` int(255) NOT NULL,
  `tbl_team_id` int(255) NOT NULL,
  `tbl_question_id` int(255) NOT NULL,
  `user_answer` int(255) NOT NULL,
  `username` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_all_joined_question`
--

INSERT INTO `tbl_all_joined_question` (`id`, `tbl_team_id`, `tbl_question_id`, `user_answer`, `username`) VALUES
(1, 1, 1, 2, 'mohsin359'),
(2, 1, 2, 1, 'mohsin359'),
(3, 0, 3, 2, 'hasan'),
(4, 0, 4, 2, 'hasan'),
(5, 0, 5, 1, 'hasan'),
(6, 0, 3, 2, 'mohsin359'),
(7, 0, 4, 1, 'mohsin359'),
(8, 0, 5, 2, 'mohsin359'),
(9, 0, 3, 1, 'aaa111'),
(10, 1, 1, 2, 'mvc452'),
(11, 1, 2, 2, 'mvc452'),
(12, 0, 3, 2, 'adiikakkar'),
(13, 0, 4, 1, 'adiikakkar'),
(14, 0, 5, 1, 'adiikakkar'),
(15, 1, 1, 2, 'adiikakkar'),
(16, 1, 2, 2, 'adiikakkar'),
(17, 0, 3, 1, 'Killer99'),
(18, 0, 4, 2, 'Killer99'),
(19, 0, 5, 1, 'Killer99'),
(20, 1, 1, 1, 'ayush'),
(21, 1, 2, 2, 'ayush'),
(22, 0, 3, 1, 'ayush'),
(23, 0, 4, 1, 'ayush'),
(24, 0, 5, 1, 'ayush'),
(25, 0, 3, 1, 'devshukla'),
(26, 0, 4, 2, 'devshukla'),
(27, 0, 5, 1, 'devshukla'),
(28, 0, 3, 1, 'Md Akmal Aziz'),
(29, 0, 4, 2, 'Md Akmal Aziz'),
(30, 0, 5, 2, 'Md Akmal Aziz'),
(31, 0, 3, 1, 'hittt'),
(32, 0, 4, 1, 'hittt'),
(33, 0, 5, 1, 'hittt'),
(34, 0, 3, 1, 'AlphaM'),
(35, 0, 4, 1, 'AlphaM'),
(36, 0, 5, 1, 'AlphaM'),
(37, 2, 6, 2, 'mohsin359'),
(38, 2, 6, 1, 'hasan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_game_history`
--

CREATE TABLE `tbl_game_history` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `game_id` int(11) NOT NULL,
  `replay` int(11) NOT NULL,
  `total_earning` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_game_tournament`
--

CREATE TABLE `tbl_game_tournament` (
  `id` int(11) NOT NULL,
  `game_name` varchar(500) NOT NULL,
  `game_icon` varchar(500) NOT NULL,
  `total_player` int(255) NOT NULL,
  `allow_player` int(255) NOT NULL,
  `prize_pool` int(255) NOT NULL,
  `entry_fee` int(255) NOT NULL,
  `end_time` time NOT NULL,
  `entry_date` date NOT NULL,
  `game_url` varchar(500) NOT NULL,
  `status` int(11) NOT NULL,
  `date` date NOT NULL,
  `t_status` int(11) NOT NULL,
  `background` varchar(500) NOT NULL,
  `rotation` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_game_tournament`
--

INSERT INTO `tbl_game_tournament` (`id`, `game_name`, `game_icon`, `total_player`, `allow_player`, `prize_pool`, `entry_fee`, `end_time`, `entry_date`, `game_url`, `status`, `date`, `t_status`, `background`, `rotation`) VALUES
(1, 'Tower Build', 'http://wpwala.com/nostragumus/upcoming/images/tower_logo.png', 2, 50, 80, 2, '20:00:00', '2020-06-19', 'https://wpwala.com/nostragumus/spin/game/tower/', 2, '2020-07-05', 0, 'jnj', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_host`
--

CREATE TABLE `tbl_host` (
  `id` int(11) NOT NULL,
  `match_name` varchar(500) NOT NULL,
  `status` varchar(11) NOT NULL,
  `winning_prize` int(11) NOT NULL,
  `per_kill` int(11) NOT NULL,
  `entry_fee` int(11) NOT NULL,
  `total_join` int(11) NOT NULL,
  `cover` varchar(500) NOT NULL,
  `icon` varchar(500) NOT NULL,
  `game_date` date NOT NULL,
  `game_time` time NOT NULL,
  `room_id` varchar(500) NOT NULL,
  `room_pass` varchar(500) NOT NULL,
  `room_status` varchar(255) NOT NULL,
  `room_size` int(11) NOT NULL,
  `video` varchar(500) NOT NULL,
  `rules` text NOT NULL,
  `version` varchar(255) NOT NULL,
  `platform` varchar(500) NOT NULL,
  `match_type` varchar(500) NOT NULL,
  `created_date` datetime NOT NULL,
  `map` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_host`
--

INSERT INTO `tbl_host` (`id`, `match_name`, `status`, `winning_prize`, `per_kill`, `entry_fee`, `total_join`, `cover`, `icon`, `game_date`, `game_time`, `room_id`, `room_pass`, `room_status`, `room_size`, `video`, `rules`, `version`, `platform`, `match_type`, `created_date`, `map`) VALUES
(1, 'PubG', 'Upcoming', 1000, 5, 10, 1, 'https://i.ibb.co/FbrRdWn/temp-holder.png', 'https://i.ibb.co/3Yqjjrn/dddd.png', '2020-08-10', '20:00:00', ' ', ' ', '', 100, '', '<p>A&nbsp;<strong>tournament</strong>&nbsp;is a competition involving a relatively large number of competitors, all participating in a sport or game. More specifically, the term may be used in either of two overlapping senses: One or more competitions held at a single venue and concentrated into a relatively short time interval.</p>\r\n\r\n<p>A&nbsp;<strong>tournament</strong>&nbsp;is a competition involving a relatively large number of competitors, all participating in a sport or game. More specifically, the term may be used in either of two overlapping senses: One or more competitions held at a single venue and concentrated into a relatively short time interval.</p>\r\n\r\n<p>&quot;</p>\r\n\r\n<p>&quot;</p>\r\n\r\n<p>&quot;</p>\r\n', 'TPP', 'Pub G', 'Squad', '2020-06-19 00:00:00', '*****'),
(2, 'Ludo King Champ', 'Upcoming', 1000, 10, 20, 0, 'https://techkky.com/wp-content/uploads/2020/06/maxresdefault-3-1068x601.jpg', 'https://img.etimg.com/thumb/width-640,height-480,imgsize-131196,resizemode-1,msid-76314521/small-biz/startups/features/a-winner-how-ludo-became-the', '2020-07-31', '20:00:00', ' ', ' ', '', 10, '', '<p>Ludo King Champ&nbsp;Ludo King Champ&nbsp;Ludo King Champ&nbsp;Ludo King Champ&nbsp;Ludo King Champ&nbsp;Ludo King Champ&nbsp;Ludo King Champ&nbsp;Ludo King Champ</p>\r\n\r\n<p>Ludo King Champ&nbsp;Ludo King Champ&nbsp;Ludo King Champ&nbsp;Ludo King Champ&nbsp;Ludo King Champ&nbsp;Ludo King Champ</p>\r\n\r\n<p>&quot;</p>\r\n\r\n<p>&quot;</p>\r\n\r\n<p>&quot;</p>\r\n', 'TPP', 'Pub G', 'Squad', '2020-07-16 00:00:00', '*****');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_host_join`
--

CREATE TABLE `tbl_host_join` (
  `id` int(11) NOT NULL,
  `tbl_host` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `join_date` date NOT NULL,
  `entry_fee` int(11) NOT NULL,
  `total_kill` int(11) NOT NULL,
  `winning` int(11) NOT NULL,
  `user_game` varchar(500) NOT NULL,
  `rank` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_host_join`
--

INSERT INTO `tbl_host_join` (`id`, `tbl_host`, `username`, `join_date`, `entry_fee`, `total_kill`, `winning`, `user_game`, `rank`) VALUES
(1, 1, 'mohsin359', '2020-06-20', 10, 0, 0, 'mohsin359', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_join_game_tournment`
--

CREATE TABLE `tbl_join_game_tournment` (
  `id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `score` bigint(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `entry_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_join_game_tournment`
--

INSERT INTO `tbl_join_game_tournment` (`id`, `game_id`, `username`, `score`, `rank`, `amount`, `entry_date`) VALUES
(1, 1, 'mohsin359', 0, 1, 0, '2020-06-20');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_policy`
--

CREATE TABLE `tbl_policy` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_policy`
--

INSERT INTO `tbl_policy` (`id`, `name`, `content`) VALUES
(1, 'policy', 'Policy'),
(2, 'support', 'How to pla'),
(3, 'how', 'It’s pretty easy to change the color of just one WordPress menu entry, you need to do three things. First you need to find the navigation menu ID that your website is associating to that navigation menu entry. Second you’ll add in some custom CSS that will make that menu entry a different color. Lastly, customize the colors of that sample CSS to match your website.\r\n                ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_prize_distribution`
--

CREATE TABLE `tbl_prize_distribution` (
  `id` int(11) NOT NULL,
  `tbl_team_id` varchar(255) NOT NULL,
  `ranks` varchar(255) NOT NULL,
  `prize` varchar(255) NOT NULL,
  `entry_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_prize_distribution`
--

INSERT INTO `tbl_prize_distribution` (`id`, `tbl_team_id`, `ranks`, `prize`, `entry_date`) VALUES
(1, '1', '101-1000', '12', '2020-06-19'),
(2, '1', '1-100', '20', '2020-06-19');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_question`
--

CREATE TABLE `tbl_question` (
  `id` int(255) NOT NULL,
  `tbl_team_id` varchar(500) CHARACTER SET utf32 NOT NULL,
  `question` varchar(500) NOT NULL,
  `opt1` varchar(250) NOT NULL,
  `opt2` varchar(250) NOT NULL,
  `correct` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_question`
--

INSERT INTO `tbl_question` (`id`, `tbl_team_id`, `question`, `opt1`, `opt2`, `correct`) VALUES
(1, '1', 'Cricket World Cup 1983 Winner Nation?', 'West Indies', 'India', 2),
(2, '1', 'Which Team Will Win?', 'Bengal Tigers', 'HGCC', 1),
(3, '0', 'Which Team Will Win?', 'India', 'Pakistan', 1),
(4, '0', 'Which Team Will Bat First?', 'India', 'Pakistan', 2),
(5, '0', 'Which Team Will Hit More Sixes?', 'India', 'Pakistan', 1),
(6, '2', 'fdas', '1', '1', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_team`
--

CREATE TABLE `tbl_team` (
  `id` int(11) NOT NULL,
  `quiz_name` varchar(200) NOT NULL,
  `quiz_type` varchar(500) NOT NULL,
  `quiz_type_icon` varchar(200) NOT NULL,
  `team_one_icon` varchar(500) NOT NULL,
  `team_two_icon` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `entry_fee` varchar(500) NOT NULL,
  `quiz_prize` varchar(500) NOT NULL,
  `total_question` int(255) NOT NULL,
  `total_joined` varchar(500) NOT NULL,
  `total_allowed` varchar(500) NOT NULL,
  `status` int(11) NOT NULL,
  `time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_team`
--

INSERT INTO `tbl_team` (`id`, `quiz_name`, `quiz_type`, `quiz_type_icon`, `team_one_icon`, `team_two_icon`, `date`, `entry_fee`, `quiz_prize`, `total_question`, `total_joined`, `total_allowed`, `status`, `time`) VALUES
(1, 'Sports', 'T20 Match', 'http://wpwala.com/nostragumus/bazzi_now/admin/dist/img/logo.png', 'https://cricfreakapp.com/static/team_flag_BTC.png', 'https://cricfreakapp.com/static/team_flag_GHG.png', '2020-07-30', '10', '10000', 2, '4', '1200', 0, '20:00:00'),
(2, 'Cricket League', 'T20 Match', 'https://cricfreakapp.com/static/team_flag_GHG.png', 'https://cricfreakapp.com/static/team_flag_GHG.png', 'https://cricfreakapp.com/static/team_flag_BTC.png', '2020-08-20', '10', '10', 1, '4', '10', 0, '12:00:00'),
(3, 'Cricket Quiz', 'Sports', 'https://cricfreakapp.com/static/team_flag_GHG.png', 'https://cricfreakapp.com/static/team_flag_BTC.png', 'https://cricfreakapp.com/static/team_flag_GHG.png', '2020-08-22', '20', '500', 0, '', '20', 0, '20:00:00'),
(4, 'Sports', 'T20 Match', 'http://wpwala.com/nostragumus/bazzi_now/admin/dist/img/logo.png', 'https://cricfreakapp.com/static/team_flag_GHG.png', 'https://cricfreakapp.com/static/team_flag_BTC.png', '2020-07-28', '25', '1000', 0, '', '35', 0, '12:00:00'),
(5, 'Bengal Tigers vs HGCC', 'Sports', 'http://wpwala.com/nostragumus/bazzi_now/admin/dist/img/logo.png', 'https://cricfreakapp.com/static/team_flag_BTC.png', 'https://cricfreakapp.com/static/team_flag_GHG.png', '2020-07-26', '50', '500', 0, '', '12', 0, '12:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_team_joined`
--

CREATE TABLE `tbl_team_joined` (
  `id` int(255) NOT NULL,
  `tbl_team_id` varchar(500) NOT NULL,
  `username` varchar(500) NOT NULL,
  `point` bigint(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `t_status` int(11) NOT NULL,
  `win_amount` int(11) NOT NULL,
  `payout_status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_team_joined`
--

INSERT INTO `tbl_team_joined` (`id`, `tbl_team_id`, `username`, `point`, `rank`, `t_status`, `win_amount`, `payout_status`) VALUES
(1, '1', 'mohsin359', 4, 1, 1, 0, 0),
(2, '1', 'mvc452', 0, 2, 1, 0, 0),
(3, '1', 'adiikakkar', 0, 2, 1, 0, 0),
(4, '1', 'ayush', -4, 3, 1, 0, 0),
(7, '2', 'mohsin359', 0, 1, 1, 0, 0),
(8, '2', 'hasan', 0, 1, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_update`
--

CREATE TABLE `tbl_update` (
  `id` int(11) NOT NULL,
  `version` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_update`
--

INSERT INTO `tbl_update` (`id`, `version`) VALUES
(0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `team_activity_tracker`
--

CREATE TABLE `team_activity_tracker` (
  `id` int(11) NOT NULL,
  `tbl_team_id` int(11) NOT NULL,
  `tbl_question_id` int(11) NOT NULL,
  `point` decimal(11,0) NOT NULL,
  `username` varchar(200) NOT NULL,
  `entry_date` date NOT NULL,
  `type` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team_activity_tracker`
--

INSERT INTO `team_activity_tracker` (`id`, `tbl_team_id`, `tbl_question_id`, `point`, `username`, `entry_date`, `type`) VALUES
(1, 1, 1, '2', 'mohsin359', '2020-07-15', 'Correct Answer'),
(2, 1, 1, '2', 'mvc452', '2020-07-15', 'Correct Answer'),
(3, 1, 1, '2', 'adiikakkar', '2020-07-15', 'Correct Answer'),
(4, 1, 1, '-2', 'ayush', '2020-07-15', 'Wrong Answer'),
(5, 1, 2, '2', 'mohsin359', '2020-07-15', 'Correct Answer'),
(6, 1, 2, '-2', 'mvc452', '2020-07-15', 'Wrong Answer'),
(7, 1, 2, '-2', 'adiikakkar', '2020-07-15', 'Wrong Answer'),
(8, 1, 2, '-2', 'ayush', '2020-07-15', 'Wrong Answer');

-- --------------------------------------------------------

--
-- Table structure for table `tracker`
--

CREATE TABLE `tracker` (
  `id` int(255) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `points` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `transation` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tracker`
--

INSERT INTO `tracker` (`id`, `username`, `points`, `type`, `date`, `transation`) VALUES
(1, 'mohsin359', '-10', 'Fantasy Quiz Join', '2020-06-19', ''),
(2, 'mohsin359', '-10', 'Sports Live Quiz Join', '2020-06-19', ''),
(3, 'Vicky7193', '4', 'Spin wheel', '2020-06-20', ''),
(4, 'trustonsahil@gmail.com', '3', 'Spin wheel', '2020-06-20', ''),
(5, 'hasan', '0', 'Spin wheel', '2020-06-20', ''),
(6, 'mohsin359', '10', 'PubG', '2020-06-20', ''),
(7, 'mohsin359', '-10', 'Lucky Money', '2020-06-20', ''),
(8, 'mohsin359', '-10', 'Lucky Money', '2020-06-20', ''),
(9, 'mohsin359', '-10', 'Lucky Money', '2020-06-20', ''),
(10, 'mohsin359', '-200', 'Play :Tower Build', '2020-06-20', ''),
(11, 'MehdiDz', '5', 'Spin wheel', '2020-06-21', ''),
(12, 'BiBelgium', '10', 'Spin wheel', '2020-06-21', ''),
(13, 'BiBelgium', '-10', 'Lucky Money', '2020-06-21', ''),
(14, 'hasan', '10', '', '2020-06-21', ''),
(15, 'mohsin359', '10', 'Refer & Earn', '2020-06-21', ''),
(16, 'hasan', '-10', 'Sports Live Quiz Join', '2020-06-21', ''),
(17, 'kunalsahu', '9', 'Spin wheel', '2020-06-21', ''),
(18, 'MehdiDz1', '10', '', '2020-06-21', ''),
(19, 'MehdiDz', '10', 'Refer & Earn', '2020-06-21', ''),
(20, 'Amit Pandit', '8', 'Spin wheel', '2020-06-21', ''),
(21, 'hasan', '7', 'Spin wheel', '2020-06-21', ''),
(22, 'mvc452', '-10', 'Fantasy Quiz Join', '2020-06-21', ''),
(23, 'hasan', '7', 'Spin wheel', '2020-06-22', ''),
(24, 'mohsin359', '0', 'Sports Live Quiz Win', '2020-06-22', ''),
(25, 'hasan', '25', 'Sports Live Quiz Win', '2020-06-22', ''),
(26, 'qwertyyy', '0', 'Spin wheel', '2020-06-23', ''),
(27, 'dhimds', '3', 'Spin wheel', '2020-06-24', ''),
(28, 'adiikakkar', '10', 'Add Coin UPI', '2020-06-24', ''),
(29, 'adiikakkar', '-10', 'Fantasy Quiz Join', '2020-06-24', ''),
(30, 'adiikakkar', '-10', 'Lucky Money', '2020-06-24', ''),
(31, 'miku1', '9', 'Spin wheel', '2020-06-24', ''),
(32, 'hasan', '10', 'Spin wheel', '2020-06-24', ''),
(33, 'adiikakkar', '11', 'Spin wheel', '2020-06-24', ''),
(34, 'hasan', '-20', 'Bollywood Live Quiz Join', '2020-06-24', ''),
(35, 'Killer99', '4', 'Spin wheel', '2020-06-24', ''),
(36, 'ayush', '-10', 'Fantasy Quiz Join', '2020-06-24', ''),
(37, 'ayush', '10', 'Spin wheel', '2020-06-24', ''),
(38, 'mohsin359', '-10', 'Lucky Money', '2020-06-24', ''),
(39, 'mohsin359', '-10', 'Lucky Money', '2020-06-24', ''),
(40, 'mohsin359', '-10', 'Lucky Money', '2020-06-24', ''),
(41, 'mohsin359', '10', '', '2020-06-25', ''),
(42, 'hasan', '10', 'Refer & Earn', '2020-06-25', ''),
(43, 'mohsin359', '10', 'Refer and Earn', '2020-06-25', ''),
(44, 'mohsin359', '2', 'Spin wheel', '2020-06-25', ''),
(45, 'adiikakkar', '-10', 'Lucky Money', '2020-06-25', ''),
(46, 'mohsin359', '10', 'Spin wheel', '2020-06-25', ''),
(47, 'mohsin359', '-10', 'Sports Live Quiz Join', '2020-06-25', ''),
(48, 'mohsin359', '11', 'Spin wheel', '2020-06-26', ''),
(49, 'mohsin359', '4', 'Spin wheel', '2020-06-28', ''),
(50, 'mohsin359', '3', 'Spin wheel', '2020-06-30', ''),
(51, 'mohsin359', '1', 'Spin wheel', '2020-07-02', ''),
(52, 'mohsin359', '6', 'Spin wheel', '2020-07-03', ''),
(53, 'mohsin359', '-0', 'Bollywood Live Quiz Join', '2020-07-04', ''),
(54, 'mohsin359', '1', 'Spin wheel', '2020-07-06', ''),
(55, 'devshukla', '10', 'Spin wheel', '2020-07-08', ''),
(56, 'devshukla', '-10', 'Lucky Money', '2020-07-09', ''),
(57, 'devshukla', '-10', 'Lucky Money', '2020-07-09', ''),
(58, 'devshukla', '-10', 'Lucky Money', '2020-07-09', ''),
(59, 'devshukla', '-10', 'Lucky Money', '2020-07-09', ''),
(60, 'devshukla', '-10', 'Lucky Money', '2020-07-09', ''),
(61, 'devshukla', '-10', 'Lucky Money', '2020-07-09', ''),
(62, 'devshukla', '-10', 'Lucky Money', '2020-07-09', ''),
(63, 'devshukla', '-10', 'Lucky Money', '2020-07-09', ''),
(64, 'devshukla', '-10', 'Lucky Money', '2020-07-09', ''),
(65, 'devshukla', '-10', 'Lucky Money', '2020-07-09', ''),
(66, 'devshukla', '-10', 'Lucky Money', '2020-07-09', ''),
(67, 'mohsin359', '-10', 'Lucky Money', '2020-07-10', ''),
(68, 'mohsin359', '2', 'Spin wheel', '2020-07-10', ''),
(69, '女 VICKY 女 女 HYDRA', '7', 'Spin wheel', '2020-07-14', ''),
(70, 'Mansa', '2', 'Spin wheel', '2020-07-14', ''),
(71, 'hittt', '7', 'Spin wheel', '2020-07-14', ''),
(72, 'fakroo', '6', 'Spin wheel', '2020-07-14', ''),
(73, 'hasan', '8', 'Spin wheel', '2020-07-14', ''),
(74, 'jav12345', '7', 'Spin wheel', '2020-07-15', ''),
(75, 'mohsin359', '11', 'Spin wheel', '2020-07-15', ''),
(76, 'mohsin359', '10', 'Fantasy Quiz Join', '2020-07-15', ''),
(77, 'mohsin359', '-10', 'Fantasy Quiz Join', '2020-07-15', ''),
(78, 'mohsin359', '-10', 'Fantasy Quiz Join', '2020-07-15', ''),
(79, 'hasan', '-50', 'Sports Live Quiz Join', '2020-07-16', ''),
(80, 'hasan', '55', 'Sports Live Quiz Win', '2020-07-16', ''),
(81, 'hasan', '-10', 'Fantasy Quiz Join', '2020-07-16', ''),
(82, 'hasan', '4', 'Spin wheel', '2020-07-16', ''),
(83, 'hasan', '-10', 'Lucky Money', '2020-07-16', ''),
(84, 'kapil03', '7', 'Spin wheel', '2020-07-17', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fcm_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `points` bigint(255) NOT NULL DEFAULT 0,
  `refer` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `ip_address` char(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `status` int(10) UNSIGNED DEFAULT 0,
  `refer_status` int(11) NOT NULL DEFAULT 0,
  `social_status` varchar(128) COLLATE utf8_unicode_ci DEFAULT '0',
  `date_registered` timestamp NOT NULL DEFAULT current_timestamp(),
  `phone` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `badge` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `email`, `fcm_id`, `points`, `refer`, `ip_address`, `status`, `refer_status`, `social_status`, `date_registered`, `phone`, `image`, `badge`) VALUES
(1, 'Mohsin Jawwad', 'mohsin359', 'Mohsin823', 'mohsinjawed359@gmail.com', '0', 0, 'T33UKGN8', '0', 0, 1, '0', '2020-06-19 20:58:14', '+918172967999', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(2, 'Baazi Live', 'hasan', 'Mohsin823', 'mohsinjawwad359@gmail.com', '0', 3397, '9V8E8H9W', '0', 0, 1, '0', '2020-06-19 21:47:32', '+919517193081', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(3, 'Vicky', 'Vicky7193', '88888888', 'v4vkrn45@gmail.com', '0', 0, '9P1TIULN', '0', 0, 0, '0', '2020-06-20 13:33:02', '+918305060005', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(4, 'Sahil', 'trustonsahil@gmail.com', '728692', 'trustonsahil@gmail.com', '0', 3, 'BYCRD0T3', '0', 0, 0, '0', '2020-06-20 14:25:20', '+918757336637', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(5, 'MehdiDz', 'MehdiDz', '123456', 'alfa072022@gmail.com', '0', 15, 'KECP0SAE', '0', 0, 0, '0', '2020-06-21 00:19:23', '+213665135056', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(6, 'bbaa', 'BiBelgium', 'test2020', 'gantsetseg2017@gmail.com', '0', 0, 'J0DWJX46', '0', 0, 0, '0', '2020-06-21 02:03:52', '+32488239237', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(7, 'a', 'aaaaa', '123', 'a@gmail.com', '0', 0, '9YJ8RULL', '0', 0, 0, '0', '2020-06-21 05:40:49', '+918802361160', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(8, 'aaaa', 'aaa111', 'Aniket123', 'sportindia1125@gmail.con', '0', 0, '24R2WJY1', '0', 0, 0, '0', '2020-06-21 08:53:02', '+917435068002', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(9, 'kunal', 'kunalsahu', '12345', 'info@softechplanets.com', '0', 9, 'KUBAEGBT', '0', 0, 0, '0', '2020-06-21 10:06:09', '+919907026112', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(10, 'mayur', 'Mayur varshney', '12345678', 'mayurvarshney.mv26@gmail.com', '0', 0, '0WTAYJSA', '0', 0, 0, '0', '2020-06-21 10:17:05', '+918266887454', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(11, 'MehdiDz 1', 'MehdiDz1', '123456', 'alfa072023@gmail.com', '0', 10, '7FBUP6MG', '0', 0, 1, '0', '2020-06-21 10:54:45', '+213698500373', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(12, 'kunal', 'kunaldahiya', '1539', 'kunaldahiya1539@gmail.com', '0', 0, 'YBZY3JG3', '0', 0, 0, '0', '2020-06-21 12:33:30', '+917027048155', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(13, 'hhh', 'Amit Pandit', '989898', 'mramit9896653538@gmail.com', '0', 8, 'VUS6LWOJ', '0', 0, 0, '0', '2020-06-21 17:11:14', '+917988990792', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(14, 'ManiGandan', 'msmanigandan228', 'Live@2020', 'msmanigandan228@gmail.com', 'dfVc9bNlo4g:APA91bEZg-8tdK5wjGGtX_ZSnoyr6b476VbzYIoEVbF41yrjTcU2Nh-wnrsaYjJf6wkVAe_Be32Ize2fDhON4C04rjsWUn1EHGADGWdzKasEIRLd9-q6Gcp8uqWSj4KpalVlwHnWaw3s', 0, 'Z2JPY1MA', '0', 0, 0, '0', '2020-06-21 18:39:48', '+919150861989', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(15, 'Muhammad Uzair', 'muhammaduzair', 'qwerty', 'uzairmajeed45@gmail.com', '0', 0, 'KQRYA8JE', '0', 0, 0, '0', '2020-06-21 19:29:00', '+923366297714', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(16, 'test', 'mvc452', 'Venky@52', 'venkyviva52@gmail.com', '0', -10, '3XTHJYH2', '0', 0, 0, '0', '2020-06-21 21:21:32', '+918501011666', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(17, 'dhadukkeyur', 'dk infotech', '1234', 'dkinfotech2401@gmail.com', '0', 0, '7Z9EJF1F', '0', 0, 0, '0', '2020-06-22 11:34:51', '+919824948013', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(18, 'gaurav', 'gaurav706', '1388', 'ygaurav706@gmail.com', '0', 0, '73DE3L2C', '0', 0, 0, '0', '2020-06-22 17:41:55', '+917988593559', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(19, 'qwerty', 'qwerty', 'qwerty', 'Rushikesh.sanap.98@gmail.com', '0', 0, 'FLTN3ARU', '0', 0, 0, '0', '2020-06-23 08:28:14', '+918830956873', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(20, 'rajesh', 'rajeshpalawat', 'Chandan@ji01', 'arjcart@gmail.com', '0', 0, 'Q84WNK4D', '0', 0, 0, '0', '2020-06-23 09:23:51', '+919610120145', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(21, 'vikash thakur', 'vikash', '967849', 'vikashthakur9707@gmail.com', '0', 0, 'LLRUDL5Q', '0', 0, 0, '0', '2020-06-23 10:46:20', '+918402846770', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(22, 'hemanta', 'hemanta', '12345', 'dailypayofficial@gmail.com', '0', 0, '62FLVD2J', '0', 0, 0, '0', '2020-06-23 12:41:29', '+918638797545', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(23, 'ritik', 'ritik001', '9G0T6C3O', 'ritikkundu44@gmail.com', '0', 0, '6LA8Y96J', '0', 0, 0, '0', '2020-06-23 15:36:37', '+919817698127', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(24, 'ankit', 'ankit001', 'ritik123', 'ritikharyana@gmail.com', '0', 0, 'HEICDBQ2', '0', 0, 0, '0', '2020-06-23 15:42:53', '+918816041010', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(25, 'niledh', 'nilesh7747', 'golden7747', 'nooorcreation@gmail.com', '0', 0, 'OQR50QR8', '0', 0, 0, '0', '2020-06-23 18:44:23', '+919898050060', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(26, 'qwertyyy', 'qwertyyy', '12345678', 'qwertyyy@qwerty.com', '0', 0, 'Y9U4BK5S', '0', 0, 0, '0', '2020-06-23 18:51:48', '+917907061912', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(27, 'Iury Martins', 'dhimds', '91i20xt@', 'imds.webmaster@gmail.com', '0', 3, 'VS13KLI8', '0', 0, 0, '0', '2020-06-24 02:15:58', '+5562996961933', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(28, 'Naveen', 'Tom Naveen', '12345y78', 'naveemeee@gmail.com', '0', 0, 'GEW0K3ZS', '0', 0, 0, '0', '2020-06-24 04:39:40', '+918825730268', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(29, 'Aditya', 'adiikakkar', '', 'adityakukkar444a@gmail.com', '0', 11, 'T6MXPPJU', '0', 0, 0, '0', '2020-06-24 05:55:35', '+917015575705', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(30, 'miku', 'miku1', 'miku123', 'na@na.com', '0', 9, 'J4F937K6', '0', 0, 0, '0', '2020-06-24 06:47:52', '+917008199125', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(31, 'Farez', 'Farez', 'farez', 'farezapps@gmail.com', '0', 0, 'BMYQZ9B9', '0', 0, 0, '0', '2020-06-24 13:10:11', '+51983006690', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(32, 'rajan Kumar', 'rajankumar00', 'rajankumar00', 'rk2377322@gmail.com', '0', 0, 'Y36ZDBXK', '0', 0, 0, '0', '2020-06-24 13:58:17', '+916306427685', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(33, 'Alok kumar', 'AlokkKumar', '98XRTDBG', 'ak9138992@gmail.com', '0', 0, 'JFXHOHZU', '0', 0, 0, '0', '2020-06-24 13:58:46', '+919336846828', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(34, 'killer', 'Killer99', '1234567890', 'qwertyuiop@gmail.com', '0', 4, 'JY3A1RNU', '0', 0, 0, '0', '2020-06-24 14:43:51', '+919953544475', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(35, 'ayush', 'ayush', '12345', 'atush123@gmail.com', '0', 0, 'YEOTXDK1', '0', 0, 0, '0', '2020-06-24 18:33:47', '+918587989464', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(57, 'mani', 'mani@619', '2525', 'misrapavan8@gmail.com', '0', 0, 'LFM44FQM', '0', 0, 0, '0', '2020-07-16 00:30:35', '+919727828619', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(36, 'manoj', 'manoj123', '123456', 'manoj.hanumat1984@gmail.com', '0', 0, 'BU12NYG5', '0', 0, 0, '0', '2020-06-28 15:42:53', '+919519008483', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(37, 'surah', 'SURAJ', 'Suraj1043', 'surajsahni2002@gmail.com', '0', 0, '4SX4PP0Y', '0', 0, 0, '0', '2020-07-01 17:34:09', '+917082431043', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(38, 'dev', 'devshukla', 'devshukla', 'devshukla@gmail.com', '0', -100, '9V9I11ZG', '0', 0, 0, '0', '2020-07-08 15:52:14', '+918318170732', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(39, 'Maaz', 'MaazArfi', 'xyzxyz', 'mrftrafficingtech@gmail.com', '0', 0, 'KXRP356R', '0', 0, 0, '0', '2020-07-13 13:25:59', '+918931863425', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(40, 'sb', 'sbsb9', '1234', 'su@gmail.com', '0', 0, 'Y1ZZTN22', '0', 0, 0, '0', '2020-07-14 03:21:15', '+917008196945', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(41, 'vucc', '女 VICKY 女 女 HYDRA', '845854085575', 'bankarakshay8485@gmail.com', '0', 7, 'BXAVBL6U', '0', 0, 0, '0', '2020-07-14 03:23:15', '+918208790755', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(42, 'Mansa', 'Mansa', '12345678', 'earnningtime476@gmail.com', '0', 2, 'T0HRQQ2T', '0', 0, 0, '0', '2020-07-14 03:27:26', '+917419093904', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(43, 'Akmal', 'Md Akmal Aziz', '', 'mdakmalaziz786@gmail.com', '0', 0, 'T1GOHJ3M', '0', 0, 0, '0', '2020-07-14 03:52:07', '+916202579164', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(44, 'haiff', 'hhhhh', '1234', 'hessfhtsdj@gmail.com', '0', 0, 'RG31RXEK', '0', 0, 0, '0', '2020-07-14 04:04:36', '+919782910002', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(45, 'hitt', 'hittt', '1234', 'starv7618@gmail.com', '0', 7, 'NPCA9LLP', '0', 0, 0, '0', '2020-07-14 04:43:24', '+917984092344', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(46, 'himanshu', 'himanshu', 'hari@7998', 'himanshupatel199@yahoo.com', '0', 0, '5YF0RO65', '0', 0, 0, '0', '2020-07-14 05:10:45', '+918140776651', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(47, 'fakroo', 'fakroo', '0786786', 'videoadsearn@gmail.com', '0', 6, 'D22HGL92', '0', 0, 0, '0', '2020-07-14 05:25:06', '+919634080995', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(48, 'Shivam kumar', 'ShivamSingh', 'Shivam1234', '2shivam1singh@gmail.com', '0', 0, 'ZOTHOCFI', '0', 0, 0, '0', '2020-07-14 06:34:09', '+919110054881', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(49, 'aman', 'aman89', 'aman786', 'tushardagar230@gmail.com', '0', 0, 'MP6J99H6', '0', 0, 0, '0', '2020-07-14 14:08:46', '+919800632931', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(50, 'rp', 'rudaram', '', 'ryptrl01@gmail.com', '0', 0, 'CMKMK8YN', '0', 0, 0, '0', '2020-07-14 15:31:12', '+917375864636', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(51, 'Japhet ', 'Mr Brown', 'Jaff87', 'japhetdanjuma9@gmail.com', '0', 0, '7YR8N730', '0', 0, 0, '0', '2020-07-15 01:47:14', '+2348176548121', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(52, 'ZEESHAN ', 'zdsss', '', 'zeeshantkhan06@gmail.com', '0', 0, 'IB9RAPYA', '0', 0, 0, '0', '2020-07-15 05:05:57', '+917014391551', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(53, 'ja', 'jav12345', '12345678', 'iambad.2013@gmail.com', '0', 7, 'KUZGH4LG', '0', 0, 0, '0', '2020-07-15 08:07:22', '+918700630681', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(54, 'Alpham', 'AlphaM', '1234', 'aplmam@gmail.com', '0', 0, 'EZ075S8G', '0', 0, 0, '0', '2020-07-15 13:50:09', '+918329771339', 'https://www.freeiconspng.com/uploads/flat-face-icon-23.png', 0),
(55, 'ttt', 'ggghg', 'gfg', 'fggg@gma.com', '0', 0, 'ZNBROQ2F', '0', 0, 0, '0', '2020-07-15 16:38:28', '+919801440823', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(56, 'victor', 'gregory', '1234567ad', 'vvn21918@gmail.com', '0', 0, '6X6OG684', '0', 0, 0, '0', '2020-07-15 22:53:08', '+2348076723413', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(58, 'anil', 'anilkhatana03', '123', 'anilbitcoin03@gmail.com', '0', 0, '53TNNPQA', '0', 0, 0, '0', '2020-07-16 11:33:16', '+918368726734', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(59, 'kapil', 'kapil03', 'kapil123', 'k030188@gmail.com', '0', 7, '4SN6VUQ3', '0', 0, 0, '0', '2020-07-17 16:47:17', '+919004271881', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(60, 'Mohd manzy', 'manzoor', 'manzoor', 'mohdmanzoor0013@gmail.com', '0', 0, '3VYF1I20', '0', 0, 0, '0', '2020-07-19 10:18:26', '+917097478677', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0),
(61, 'mohit', 'mbhardwaj', 'CMY4WWM1', 'ybhardwajboy@gmail.com', '0', 0, 'FM7GCTR8', '0', 0, 0, '0', '2020-07-19 17:39:04', '+919068062563', 'https://getdrawings.com/free-icon/free-avatars-icons-53.png', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admob`
--
ALTER TABLE `admob`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `draw_result`
--
ALTER TABLE `draw_result`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game_list`
--
ALTER TABLE `game_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `live_quiz_category`
--
ALTER TABLE `live_quiz_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `live_quiz_distribution`
--
ALTER TABLE `live_quiz_distribution`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `live_quiz_join`
--
ALTER TABLE `live_quiz_join`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `live_quiz_question`
--
ALTER TABLE `live_quiz_question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `live_quiz_user_answer`
--
ALTER TABLE `live_quiz_user_answer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lucky_draw`
--
ALTER TABLE `lucky_draw`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_contests`
--
ALTER TABLE `my_contests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_requests`
--
ALTER TABLE `payment_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pollfish`
--
ALTER TABLE `pollfish`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_all_joined_question`
--
ALTER TABLE `tbl_all_joined_question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_game_history`
--
ALTER TABLE `tbl_game_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_game_tournament`
--
ALTER TABLE `tbl_game_tournament`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_host`
--
ALTER TABLE `tbl_host`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_host_join`
--
ALTER TABLE `tbl_host_join`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_join_game_tournment`
--
ALTER TABLE `tbl_join_game_tournment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_policy`
--
ALTER TABLE `tbl_policy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_prize_distribution`
--
ALTER TABLE `tbl_prize_distribution`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_question`
--
ALTER TABLE `tbl_question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_team`
--
ALTER TABLE `tbl_team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_team_joined`
--
ALTER TABLE `tbl_team_joined`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_update`
--
ALTER TABLE `tbl_update`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team_activity_tracker`
--
ALTER TABLE `team_activity_tracker`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tracker`
--
ALTER TABLE `tracker`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admob`
--
ALTER TABLE `admob`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `draw_result`
--
ALTER TABLE `draw_result`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_list`
--
ALTER TABLE `game_list`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `live_quiz_category`
--
ALTER TABLE `live_quiz_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `live_quiz_distribution`
--
ALTER TABLE `live_quiz_distribution`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `live_quiz_join`
--
ALTER TABLE `live_quiz_join`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `live_quiz_question`
--
ALTER TABLE `live_quiz_question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `live_quiz_user_answer`
--
ALTER TABLE `live_quiz_user_answer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `lucky_draw`
--
ALTER TABLE `lucky_draw`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `my_contests`
--
ALTER TABLE `my_contests`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_requests`
--
ALTER TABLE `payment_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `pollfish`
--
ALTER TABLE `pollfish`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_all_joined_question`
--
ALTER TABLE `tbl_all_joined_question`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tbl_game_history`
--
ALTER TABLE `tbl_game_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_game_tournament`
--
ALTER TABLE `tbl_game_tournament`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_host`
--
ALTER TABLE `tbl_host`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_host_join`
--
ALTER TABLE `tbl_host_join`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_join_game_tournment`
--
ALTER TABLE `tbl_join_game_tournment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_policy`
--
ALTER TABLE `tbl_policy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_prize_distribution`
--
ALTER TABLE `tbl_prize_distribution`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_question`
--
ALTER TABLE `tbl_question`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_team`
--
ALTER TABLE `tbl_team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_team_joined`
--
ALTER TABLE `tbl_team_joined`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `team_activity_tracker`
--
ALTER TABLE `team_activity_tracker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tracker`
--
ALTER TABLE `tracker`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
