<?php include 'session.php';?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Add Game Tournament</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 
</head>
<body class="hold-transition sidebar-mini" >
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
// onload="update_user($id);"
  include  'nav_barr.php';
  
  extract($_REQUEST);
 
  
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="game_tournament.php">Tournament</a></li>
              <li class="breadcrumb-item active">Add Tournament</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
              
            <div class="card-header">
 
            </div>
            <!-- /.card-header -->
            <form action="tournament_update.php" method="post">
            <div class="card-body">
                <div class="row">
                <div class="col-sm-2">
                        <label for="game_name" class="col-form-label">Game Name</label>
                         <input type="hidden" name="add_game_tournament" class="form-control" placeholder="id"  value ="1" required="required">
                         <input type="hidden" name="status" class="form-control" placeholder="id"  value ="1" required="required">
                    <input type="text" name="game_name" class="form-control" placeholder="Game Name" required="required">
                  </div>
                  <div class="col-sm-5">
                        <label for="game_icon" class="col-form-label">Game Icon</label>
                        <input type="text" name="game_icon" class="form-control" placeholder="Icon Url" required="required">
                  </div>
                  <div class="col-sm-5">
                        <label for="game_icon" class="col-form-label">Game Background</label>
                        <input type="text" name="background" class="form-control" placeholder="Background Url" required="required">
                  </div>
                   <div class="col-sm-3">
                        <label for="total_player" class="col-form-label">Total Player</label>
                        <input type="number" name="total_player" class="form-control" placeholder="total_player" required="required">
                  </div>
                  <div class="col-sm-3">
                        <label for="total_allow" class="col-form-label">Allow Player</label>
                        <input type="number" name="allow_player" class="form-control" placeholder="allow_player" required="required">
                  </div>
                  <div class="col-sm-3">
                        <label for="entry_fee" class="col-form-label">Entry Fee</label>
                        <input type="number" name="entry_fee" class="form-control" placeholder="Entry Fee" required="required">
                  </div>
                  <div class="col-sm-3">
                        <label for="prize_pool" class="col-form-label">Pool Prize</label>
                        <input type="number" name="prize_pool" class="form-control" placeholder="pool prize" required="required">
                  </div>
                  <div class="col-sm-2">
                        <label for="date" class="col-form-label">End date</label>
                        <input type="text" name="dateq" class="form-control" placeholder="2020-05-10 " required="required">
                  </div>
                  <div class="col-sm-2">
                        <label for="end_time" class="col-form-label">End Time</label>
                        <input type="text" name="end_time" class="form-control" placeholder="24:00:00" required="required">
                  </div>
                  <div class="col-sm-4">
                        <label for="game_url" class="col-form-label">Game URL</label>
                        <input type="text" name="game_url" class="form-control" placeholder="https://" required="required">
                  </div>
                  <div class="col-sm-2">
                        <label for="rotation" class="col-form-label">Rotation</label>
                         <select class="form-control" id="rotation" name="rotation">
                            <option value="1">Landscape</option>
                            <option value="2">Portrait</option>
                           
                          </select>
                       
                  </div>
                 <center> <div class="col-sm-2 text-center">
                      <label for="game_url" class="col-form-label text-white">\</label>
                        <input type="submit"class="btn btn-success" value="Add">
                  </div>
                  </center>
                 </div>
              
            </div>
            </form>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include  'side_bar.php';?>
  <!-- /.content-wrapper -->
<?php include 'footer.php';?>

  
</div>
<!-- ./wrapper -->
 <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
<?php  include 'common_js.php';?>
<!-- jQuery -->

<!-- page script -->


</body>
</html>
