<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Ongoing</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
  include 'session.php';
  include  'nav_barr.php';
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Ongoing List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Ongoing</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="sm col-6">
                        <h3 class="card-title">Showing All Ongoing</h3>
                    </div>
                     <div class="sm col-6 text-right">
                       <a href="b_add.php"><button class="btn btn-primary">+ Add</button></a>
                    </div>
                </div>
              
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive">
                <table id="example1" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>ID</th>
                 <th>Match Name(s)</th>
                  <th>Date</th>
                  <th>Join/Allow</th>
                  <th>Entry Fee</th>
                  <th>Platform</th>
                  <th>Match Type</th>
                <th>Operation</th>
                </tr>
                </thead><tbody> 
                
                
                <?php 
               $str="SELECT * FROM tbl_host WHERE status='Ongoing'";
                $query=mysqli_query($link,$str);
                  
                  while($row=mysqli_fetch_array($query)){
                   
                    $id = '"'.$row['id'].'"';
                  if($row['status']=="Ongoing") {
                    $status = "Ongoing";
                    $active = "text-primary";
                  }
                
                echo "<tr>
                <td>".$row['id']."</td>
                <td class='$active'>".$row['match_name']." | $status</td>
                <td>".$row['game_date']."</td>
                <td>".$row['total_join']."/".$row['room_size']."</td>
                 <td>".$row['entry_fee']."</td>
                 <td>".$row['platform']."</td>
                 <td>".$row['match_type']."</td>
                <td><a href='b_edit.php?id=".$row['id']."'><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href='b_view.php?id=".$row['id']."'><i class='fa fa-eye' aria-hidden='true'></i> </a>	&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-times' aria-hidden='true'></i> 	&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-trash' aria-hidden='true'></i></td> 
         </tr>";

}
?>
                </tbody></table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include 'side_bar.php';?>
  <!-- /.content-wrapper -->
 <?php include 'footer.php';?>

  <!-- Control Sidebar -->
 
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<?php include 'common_js.php';?>
<!-- page script -->
<script>
$(document).ready(function() {

  $('#example1').DataTable( {
    responsive: true
} );
});
</script>
</body>
</html>
