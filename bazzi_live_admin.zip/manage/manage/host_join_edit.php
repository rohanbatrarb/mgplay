<?php include 'session.php';?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Host Winner Edit</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 
</head>
<body class="hold-transition sidebar-mini" >
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
// onload="update_user($id);"
  include  'nav_barr.php';
  include  'side_bar.php';
  extract($_REQUEST);
  $sql = mysqli_query($link, "SELECT * FROM tbl_host_join WHERE id='$id'");
  $res = mysqli_fetch_assoc($sql);
  
  
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Winner</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
     <div class="card">
              <div class="card-header">
Edit
            </div>
            <div class="card-body">
      <div class="container">
          
    <div class="row">
        <div class="col-md-12 col-md-offset-3">
            <div class="panel panel-primary">
               
                <div class="panel-body">
                    <form role="Form" method="post" action="update_points.php" accept-charset="UTF-8">
						<div class="row form-group">
						   
						    <div class="col-sm-6">
						        <label for="question">Username</label>
							<input type="text" id="question" class="form-control" name="username" readonly value="<?php echo $res['username'];?>" placeholder="Username">
					        <input type="hidden" id="question" class="form-control" name="id" readonly value="<?php echo $res['id'];?>" placeholder="Username">
					        <input type="hidden" id="question" class="form-control" name="game_id" readonly value="<?php echo $game_id;?>" placeholder="Username">
						    </div>
						      <div class="col-sm-6">
						        <label for="question">Game Username</label>
							    <input type="text" id="question" class="form-control" name="game_user" readonly value="<?php echo $res['game_user'];?>" placeholder="Username">
					
						    </div>
						</div>
                        <div class="row form-group">
						   
						    <div class="col-sm-4">
						        <label for="question">Kill</label>
							<input type="text" id="question" class="form-control" name="kill" value="<?php echo $res['total_kill'];?>" placeholder="Kill">
					
						    </div>
						      <div class="col-sm-4">
						        <label for="question">Winning Amount</label>
							    <input type="text" id="question" class="form-control" name="winning" value="<?php echo $res['winning'];?>" placeholder="Wining">
					
						    </div>
						    <div class="col-sm-4">
						        <label for="question">Rank</label>
							    <input type="text" id="question" class="form-control" name="rank" value="<?php echo $res['rank'];?>" placeholder="Rank">
					
						    </div>
						</div>
                        
						<div class="form-group text-center">
							<button type="submit" class="btn btn-primary btn-lg" id="submitbtn" name="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include 'footer.php';?>

  
</div>
<!-- ./wrapper -->
 <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
<?php  include 'common_js.php';?>
<!-- jQuery -->

<!-- page script -->


</body>
</html>
