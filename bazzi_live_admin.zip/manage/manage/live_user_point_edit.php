<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Live Quiz Edit</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 <script src="https://cdn.ckeditor.com/4.11.3/standard/ckeditor.js"></script>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
  include 'session.php';
  include  'nav_barr.php';
  
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>User Point</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">User Point</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">User Point</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card-box">
                  
                  <h4 class="m-t-0 header-title"><b>User Points Setting</b></h4>
                  <p class="text-muted font-13 m-b-30">
                      Check All Field
                  </p>
                  <?php extract($_REQUEST);
                  $sql = mysqli_query($link,"SELECT * FROM live_quiz_join WHERE username='$username' AND quiz_id='$quiz_id'");
                  $res = mysqli_fetch_assoc($sql);
                  
                  ?>
                  <form action="update_live_quiz.php" data-parsley-validate novalidate enctype="multipart/form-data" method="post">
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="txtMtitle">Username*</label>
                          <input type="text" name="username" parsley-trigger="change" required placeholder="Enter match title" readonly value="<?php echo $res['username'];?>" class="form-control" id="txtMtitle">
                          <input type="hidden" name="live_user_update" value="1">
                          <input type="hidden" name="quiz_id" value="<?php echo $quiz_id;?>">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="txtMtitle">Rank*</label>
                         <input type="text" name="rank" readonly parsley-trigger="change" required placeholder="Enter match title" value="<?php echo $res['rank'];?>" class="form-control" id="txtMtitle">
                        </div>
                      </div>
                       <div class="col-md-6">
                        <div class="form-group">
                          <label for="txtMtitle">Score*</label>
                         <input type="text" name="icon" readonly parsley-trigger="change" required placeholder="https://.." value="<?php echo $res['score'];?>" class="form-control" id="txtMtitle">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="txtMtime">Amount*</label>
                          <input id="txtMtime" name="amount" type="number" value="<?php echo $res['amount'];?>" placeholder="Entry Fee"required class="form-control">
                        </div>
                      </div>
                    </div>
                 
                    
                   </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group text-right m-b-0">
                          <button class="btn btn-primary waves-effect waves-light" type="submit" name="btnSave" id="btnSave" > Save</button>
                          <!-- <a href="user-list.php" class="btn btn-default waves-effect waves-light m-l-5"> Cancel</a> -->
                         
                        </div>
                      </div>

                    </div>
                  </form>

                  
                </div>
              </div>
            </div>
                
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
     <?php include 'side_bar.php';?>
  

 
<!-- ./wrapper -->
<?php include 'footer.php';?>
<?php include 'common_js.php';?>
<!-- page script -->


</body>
</html>
