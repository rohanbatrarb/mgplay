<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Lucky Draw List</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
  include 'session.php';
  include  'nav_barr.php';
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Lucky Draw</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Lucky Draw</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
         <?php
          if(isset($_COOKIE['draw_update'])){
                echo '<div class="alert alert-primary" role="alert">
          Updated Successfull!
        </div>';
                
            }else if(isset($_COOKIE['draw_delete'])){
                echo '<div class="alert alert-danger" role="alert">
          Deleted!
        </div>';
            }
           ?>
        
        
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
                <div class="row">
                     <div class="col-sm-6">
                    <h3 class="card-title">Showing All Lucky Draw</h3>
                </div>
                 <div class="col-sm-6 text-right">
                    <a href="add_lucky_draw.php"><button class="btn btn-success">+ Add</button></a>
                </div>
                </div>
              
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example2" class="table table-hover" >
                <thead>
                <tr >
                  <th>ID</th>
                  <th>Lucky Draw</th>
                  <th>Total User</th>
                  <th>Status</th>
                  <th>Prize</th>
                  <th>Operation</th>
                  
                </tr>
                </thead>
                <tbody>
                 <?php
                  $str="SELECT * FROM lucky_draw ORDER BY `id` DESC";
                  $query=mysqli_query($link,$str);
                  while($row=mysqli_fetch_array($query)){
                  $id_e = $row['id'];
                  $btn = "btn-primary";
                  $active = "Running";
                  $game_icon = $row['game_icon'];
                  if($row['status']==1) {
                      $btn = "btn-danger";
                      $active = "Result Out";
                  }
                echo "<tr>
                <td>".$row['id']."</td>
                <td>".$row['lucky_draw_name']."</td>
                <td>".$row['total_user']."/".$row['total_allow_user']."</td>
                <td><a href='#' class='btn ".$btn."'>$active</a></td>
                <td>".$row['prize']."</td>
                <td><a href='lucky_draw_edit.php?id=".$row['id']."' class='btn btn-primary '>Edit</a>&nbsp;&nbsp;<input type='button' value='Delete' class='btn btn-danger' onclick='delete_lucky_draw(".$row['id'].");'/></td>
             </tr>
          ";
}?>
                </tbody>
                <tfoot>
                
                </tfoot>
              </table>
                
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include 'side_bar.php';?>
  <!-- /.content-wrapper -->
 <?php include 'footer.php';?>

  <!-- Control Sidebar -->
 
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<?php include 'common_js.php';?>
<!-- page script -->
<script>

  $(function () {
    $("#example2").DataTable();
    
  });
</script>
<script type="text/javascript">
  function status(id){
    var status_confirm=confirm("Are you Sure To this Change?");
    if(status_confirm){
      $.ajax({
        url:"all_update.php",
       data:"id="+id+"&lucky_draw_running="+1,
       //data:{"id":id},
        method:"POST",
        cache:false,
        success:function(result){
          
         var obj=JSON.parse(result);
        if(obj.result=="success"){
            location.href="lucky_draw_list.php";
              }else{
                alert(result);
              }
        }
      })
    }

  }
///////////////////////////// Delete Lucky Draw

    function delete_lucky_draw(id){
    var status_confirm=confirm("Are You Sure?");
    if(status_confirm){
      $.ajax({
        url:"all_update.php",
       data:"id="+id+"&lucky_draw_delete="+1,
       //data:{"id":id},
        method:"POST",
        cache:false,
        success:function(result){
          
         var obj=JSON.parse(result);
        if(obj.result=="success"){
            location.href="lucky_draw_list.php";
              }else{
                alert(result);
              }
        }
      })
    }

  }

 

</script>

</body>
</html>
