<?php include 'session.php';?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Add Game Tournament</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 
</head>
<body class="hold-transition sidebar-mini" >
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
// onload="update_user($id);"
  include  'nav_barr.php';
  
  extract($_REQUEST);
 
  
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="game_tournament.php">Tournament</a></li>
              <li class="breadcrumb-item active">Add Tournament</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
              
            <div class="card-header">
  <?php if(isset($_COOKIE['tournament_update'])){
          
          echo '<div class="col-sm-6">'.$_COOKIE['tournament_update'].'</div>';
        }
        else {
            echo '<div class="col-sm-6">Update Tournament</div>';
        }
        ?>
            </div>
            <!-- /.card-header -->
            <form action="tournament_update.php" method="get">
            <div class="card-body">
                <div class="row">
                    <?php
                    $select = mysqli_query($link,"SELECT * FROM tbl_game_tournament WHERE id = '$id'");
                    $res = mysqli_fetch_assoc($select);
                    
                    
                    ?>
                <div class="col-sm-2">
                        <label for="game_name" class="col-form-label">Game Name</label>
                         <input type="hidden" name="update_game_tournament" class="form-control" placeholder="id"  value ="<?php echo $id;?>" required="required">
                         <input type="hidden" name="id" class="form-control" placeholder="id"  value ="<?php echo $id;?>" required="required">
                    <input type="text" name="game_name" class="form-control" placeholder="Game Name" value="<?php echo $res['game_name'];?>"required="required">
                  </div>
                  <div class="col-sm-5">
                        <label for="game_icon" class="col-form-label">Game Icon</label>
                        <input type="text" name="game_icon" class="form-control" placeholder="Icon Url" value="<?php echo $res['game_icon'];?>" required="required">
                  </div>
                  <div class="col-sm-5">
                        <label for="game_icon" class="col-form-label">Game Background</label>
                        <input type="text" name="background" class="form-control" placeholder="Background" value="<?php echo $res['background'];?>" required="required">
                  </div>
                   <div class="col-sm-3">
                        <label for="total_player" class="col-form-label">Total Player</label>
                        <input type="number" name="total_player" class="form-control" placeholder="total_player" value="<?php echo $res['total_player'];?>" required="required">
                  </div>
                  <div class="col-sm-3">
                        <label for="total_allow" class="col-form-label">Allow Player</label>
                        <input type="number" name="allow_player" class="form-control" placeholder="allow_player" value="<?php echo $res['allow_player'];?>" required="required">
                  </div>
                  <div class="col-sm-3">
                        <label for="entry_fee" class="col-form-label">Entry Fee</label>
                        <input type="number" name="entry_fee" class="form-control" placeholder="Entry Fee" value="<?php echo $res['entry_fee'];?>" required="required">
                  </div>
                  <div class="col-sm-3">
                        <label for="prize_pool" class="col-form-label">Pool Prize</label>
                        <input type="number" name="prize_pool" class="form-control" placeholder="pool prize" value="<?php echo $res['prize_pool'];?>" required="required">
                  </div>
                  <div class="col-sm-2">
                        <label for="date" class="col-form-label">End Date</label>
                        <input type="text" name="dateq" class="form-control" placeholder="4-5-2020 "value="<?php echo $res['date'];?>" required="required">
                  </div>
                  <div class="col-sm-2">
                        <label for="end_time" class="col-form-label">End Time</label>
                        <input type="text" name="end_time" class="form-control" placeholder="24:00:00" value="<?php echo $res['end_time'];?>" required="required">
                  </div>
                  <div class="col-sm-4">
                        <label for="game_url" class="col-form-label">Game URL</label>
                        <input type="text" name="game_url" class="form-control" placeholder="https://" value="<?php echo $res['game_url'];?>"required="required">
                  </div>
                  <div class="col-sm-2">
                        <label for="rotation" class="col-form-label">Rotation</label>
                        <?php $rotation = $res['rotation'];
                            if($rotation==1) {
                                $selected1 = "selected";
                            }else {
                                $selected2 = "selected";
                            }
                            echo '<select class="form-control" id="rotation" name="rotation">
                            <option value="1" '.$selected1.'>Landscape</option>
                            <option value="2"'.$selected2.'>Portrait</option>
                           
                          </select>';
                          ?>
                  </div>
                 <center> <div class="col-sm-2 text-center">
                      <label for="game_url" class="col-form-label text-white">\</label>
                        <input type="submit"class="btn btn-success" value="Update">
                  </div>
                  </center>
                 </div>
              
            </div>
            </form>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include  'side_bar.php';?>
  <!-- /.content-wrapper -->
<?php include 'footer.php';?>

  
</div>
<!-- ./wrapper -->
 <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
<?php  include 'common_js.php';?>
<!-- jQuery -->

<!-- page script -->


</body>
</html>
