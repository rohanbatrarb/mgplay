<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Add Distribution</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 <script src="https://cdn.ckeditor.com/4.11.3/standard/ckeditor.js"></script>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
  include 'session.php';
  include  'nav_barr.php';
  extract($_REQUEST);
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Distribution</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Distribution</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Add Distribution</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card-box">
                  
                  <h4 class="m-t-0 header-title"><b>Distribution</b></h4>
                  <p class="text-muted font-13 m-b-30">
                      Fill all necessary data to Update new Rank.
                  </p>
                 
                  <form action="update_live_quiz.php" data-parsley-validate novalidate enctype="multipart/form-data" method="post">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label for="txtMtitle">Rank*</label>
                          <input type="text" name="rank" parsley-trigger="change" required placeholder="Enter Rank"  class="form-control" id="txtMtitle">
                          <input type="hidden" name="add_distribution" value="<?php echo $distribution;?>">
                        
                        </div>
                      </div>
                
                    </div>
                 
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label for="txtMtime">Amount*</label>
                          <input id="txtMtime" name="amount" type="number" placeholder="Amount"required class="form-control">
                        </div>
                      </div>
                        
                      
                    </div>
                    
                
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group text-right m-b-0">
                          <button class="btn btn-primary waves-effect waves-light" type="submit" name="btnSave" id="btnSave" > Save</button>
                          <!-- <a href="user-list.php" class="btn btn-default waves-effect waves-light m-l-5"> Cancel</a> -->
                         
                        </div>
                      </div>

                    </div>
                  </form>

                  
                </div>
              </div>
            </div>
                
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
     <?php include 'side_bar.php';?>
  

 
<!-- ./wrapper -->
<?php include 'footer.php';?>
<?php include 'common_js.php';?>
<!-- page script -->


</body>
</html>
