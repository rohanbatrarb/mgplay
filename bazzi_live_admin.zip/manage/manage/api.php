<?php include('db.php');


$key = "6808";

extract($_REQUEST);

//01. SING UP
if(isset($user_signup) && isset($access_key)) {
    $response = array();
    if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	

	$check_exits_user_query = mysqli_query($link,"SELECT * FROM users WHERE username='$username' OR phone='$phone'");
	//	$send_sql = mysqli_query($link,$check_exits_user_query);
		$re = mysqli_num_rows($check_exits_user_query);
		
	if($re>0){
		$response['error'] = "true";
		$response['message'] ="Already Have a Account";
		print_r(json_encode($response));
	    return false;
	}
	if($image=="photo"){
	     $image = "https://getdrawings.com/free-icon/free-avatars-icons-53.png";
        $rand = rand(1,10);
        if($rand ==1) {
            $image = "https://www.freeiconspng.com/uploads/flat-face-icon-23.png";
        }else if($rand==5) {
             $image = "https://www.freeiconspng.com/uploads/flat-face-icon-23.png";
        } else {
            $image = "https://getdrawings.com/free-icon/free-avatars-icons-53.png";
        }
	}	
   
    
	$register_user = mysqli_query($link,"INSERT INTO `users` SET `name`='$name',`username`='$username',
	`email`='$email',`phone`='$phone',`password`='$password',`refer`='$refer',`image`='$image',`fcm_id`='0'");

	
	if($register_user){
	    $response['error'] = false;
		$response['message'] = "User Registered successfully";
		$response['id'] = mysqli_insert_id($link);
	}else{
	    $response['error'] = true;
	    $response['message'] = "Try After Sometime";
	}
	print_r(json_encode($response));
}else
//01. Login
if(isset($user_login) && isset($access_key)) {
   
    $response = array();
    
  
    if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	$user_query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
	$sql = mysqli_query($link,$user_query);
	$data = mysqli_fetch_assoc($sql);

	if(mysqli_num_rows($sql)==1){
	    
			$response['error'] = "false";
			$response['message'] = "Successfully logged in";
			$response['data'] =$data;

	} else {
    
        	$response['error'] = "true";
			$response['message'] = "Wrong username / password! Try Again";
	}

	print_r(json_encode($response));
}else

//3. add_spin - Add Spin Points to user account and add the tracking activity
if(isset($access_key) && isset($add_spin)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	/*$check = mysqli_query($link,"SELECT * FROM users WHERE username='$username'");
	$data = mysqli_fetch_assoc($check);
	if($data['points']<$points){
	    $response['error'] = "true";
		$response['message'] = "Not Enough Coin";
		print_r(json_encode($response));
		return false;
	}*/
	if($type == 'Daily checked In' || $type == 'Daily checkin bonus'){
		$date = date('Y-m-d');
    	$sql= mysqli_query($link,"SELECT * FROM `tracker` where (`type`='Daily checkin bonus' or `type`='Daily checked In') and `username` = '$username' and date(`date`)='".date('Y-m-d')."'");
		$res = mysqli_fetch_assoc($sql);
		if(mysqli_num_rows($sql)>0) {
			$response['error'] = "true";
			$response['message'] = "You've already claimed daily bonus";
			print_r(json_encode($response));
			return false;
		}
		
	}     
	    $date = date("Y-m-d");
		if(!empty($username) && !empty($type)){
		    $date = date('Y-m-d');
		    //Add Data Tracker
		    $tracker_query = mysqli_query($link,'INSERT INTO `tracker`(`username`, `points`, `type`, `date`) VALUES 
							("'.$username.'","'.$points.'","'.$type.'","'.date('Y-m-d').'")');
		    $result = mysqli_insert_id($link);
		    //Update User Points
		    $update_user_points = mysqli_query($link,"UPDATE `users` SET `points` = `points` + '".$points."' WHERE `users`.`username` ='".$username."'");
		    
		    $response['error'] = false;
		    $response['message'] = "Points added to your wallet";
	    	$response['id'] = $result;
		} else {
		    	$response['error'] = true;
	        	$response['message'] = "Please fill all the data and submit!";
		}
	
	print_r(json_encode($response));
}else

//4. payment_request - Payment request by the user
if(isset($access_key) && isset($payment_request)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	$select_user = mysqli_query($link,"SELECT * FROM payment_requests WHERE username='$username' AND status = 0");
	
	if(mysqli_num_rows($select_user)>=1){ 
    		$response['error'] = true;
			$response['message'] = "You Already Requested";
	} else {
 	   $add_request = mysqli_query($link, 'INSERT INTO `payment_requests`(`username`, `payment_address`, `request_type`, `request_amount`, `points_used`, `remarks`, `status`,`date`) VALUES 
							("'.$username.'","'.$payment_address.'","'.$request_type.'","'.$request_amount.'","'.$points_used.'","'.$remarks.'",0,"'.date('Y-m-d').'")');
   	    $result = mysqli_insert_id($link);
	    $sql = mysqli_query($link,"UPDATE `users` SET `points` = points-$request_amount WHERE `users`.`username` ='".$username."'");
          ///////////////////////////////////
           // $random = rand(100000,999999);
			$from = "no-reply@bazzilive.com";
			$to = "mohsinjawed359@gmail.com";
			$subject = "New Payment Request | Baazi Live ";
			$text = "Hi Admin, Found New Payment Requst";
			$text .= "<br>Amount : <b>".$request_amount."</b>";
			$text .= "<br>Type : <b>".$request_type."</b>";
				$text .= "<br>User : <b>".$username."</b>";
				$text .= "<br>Payment Address : <b>".$payment_address."</b>";
			$text .= "<br><br>Please login Admin Panel and Transfer the Amount.";
			$header = "From: Payment Handle | Baazi Live <$from>\r\nReply-to: $from\r\n";
			$header .= "MIME-Version: 1.0\r\n";
			$header .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			$send =mail($to,$subject,$text,$header);
      
          
          
          ////////////////////
            //curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
          
	        $response['error'] = false;
			$response['message'] = "Your withdrawal request received";
		//	$response['request_id'] = $result;
     
	}

	print_r(json_encode($response));
}else

// 5. get_user_by_id() - get login details by user's username
if(isset($access_key) && isset($get_user_by_id)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
		$sql = mysqli_query($link,"SELECT * FROM `users` WHERE id='$id'");
		$result = mysqli_fetch_assoc($sql);
		if(mysqli_num_rows($sql)>0) {
		    $response['error'] = "false";
			$response['data'] = $result;
		} else {
		    $response['error'] = "true";
			$response['message'] = "No data found!";
		}
		
	print_r(json_encode($response));
}else
if(isset($access_key) && isset($forget_login)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	    $check = mysqli_query($link,"SELECT * FROM users WHERE phone='$phone'");
		
		if(mysqli_num_rows($check)>0){
		    $response['error']=false;
		    $update = mysqli_query($link,"UPDATE users SET password ='$password' WHERE phone='$phone'");
		}else {
		    $response['error']=true;
		    $response['message']="No Record Found";
		}
		
	print_r(json_encode($response));
}else
// 6. forget_password() - get login details by user's username
if(isset($access_key) && isset($forget_password)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
		$sql = mysqli_query($link,"SELECT * FROM `users` WHERE `email`='$email'");
		$result = mysqli_fetch_assoc($sql);
		if(mysqli_num_rows($sql)>0) {
		    
			$random = rand(100000,999999);
			$from = "no-reply@khela.com";
			$to = $email;
			$subject = "Password has been Reset by you | Khela App ";
			$text = "Hello Dear user, your password for Khela App has been reset by you. Please login via following password now. ";
			$text .= "<br>New Password : <b>".$random."</b>";
			$text .= "<br><br>Please login via following password now. <br>This password was reset by you using forgot password option<br><br><b>Khela App</b>";
			$header = "From: Password has been reset | Khela App<$from>\r\nReply-to: $from\r\n";
			$header .= "MIME-Version: 1.0\r\n";
			$header .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			$send =mail($to,$subject,$text,$header);
			if($send){
			   $sql = mysqli_query($link,"UPDATE `users` SET `password`='".md5($random)."' WHERE `email`='".$email."'");
		  		$response['error'] = "false";
			    $response['message'] = " Password has been reset and mailed to your Email. Please check the inbox";
		   
			}else{
			    $response['error'] = "true";
			    $response['message'] = "Password could not be reset! Try again!";
			}
			
			
        }else {
    	    $response['error'] = "true";
			$response['message'] = "Invalid email address! Enter correct email address!";
        }
        
        print_r(json_encode($response));
}else

// 7. set_refer_status() - set the refer status if referral code redemption is done
if(isset($access_key) && isset($set_refer_status)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
		    $sql = mysqli_query($link,"UPDATE `users` SET `refer_status`='".$refer_status."' WHERE `email`='".$email."'");
			$response['error'] = "false";
	        $response['message'] = " Refer Status set successfully";
	print_r(json_encode($response));
}else
// 8. get_refer_status() - get the refer status to check if referral code redemption is done
if(isset($access_key) && isset($get_refer_status)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
		$sql = mysqli_query($link,"select `refer_status` from `users` WHERE `email`='".$email."'");
		$result = mysqli_fetch_assoc($sql);
		$response['error'] = "false";
    	$response['refer_status'] = $result['refer_status'];
	    print_r(json_encode($response));
}else

// 9. update_profile() - update user profile

if(isset($access_key) && isset($update_profile1)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	$sql = "UPDATE `users` SET `name`='".$name."'";
	$sql .= (isset($password) && !empty($password))?" ,`password`='".md5($password)."'":"";
	$sql .= " WHERE `username`='".$username."'";
	$run = mysqli_query($link,$sql);
	if($run){
	$response['error'] = "false";
	$response['message'] = " Profile updated successfully";
	}else {
	    $response['error'] = "true";
	    $response['message'] = " Profile Not Upateded! Try Again";
	}
	print_r(json_encode($response));
	
	
}else
// 10. user_tracker() - get login details by user's username
if(isset($access_key) && isset($user_tracker)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
		$sql = mysqli_query($link,"SELECT MAX(id) as id,date FROM `tracker` WHERE username='".$username."' and points=0 and type='claim' ");
		$result = mysqli_fetch_assoc($sql);
		
		if(empty($result) || $result['id'] == ''){
			$sql = mysqli_query($link,"SELECT Min(id) as id,date FROM `tracker` WHERE username='".$username."'");
			$result = mysqli_fetch_assoc($sql);
		}
		
		$id = $result['id'];
		$date = date('d-M-Y', strtotime($result['date']));
		$sql = mysqli_query($link,"SELECT * FROM `tracker` where id >= '".$id."' and `username`='".$username."' ORDER BY `id` DESC LIMIT 30");
		$rows = array();
        while($r = mysqli_fetch_assoc($sql)) {
         $rows[] = $r;
        }
		
		if (!empty($rows)) {
			$response['error'] = "false";
			$response['message'] = "Tracking history from ".$date." onwards";
			$response['data'] = $rows;
		}else{
			$response['error'] = "true";
			$response['message'] = "No tracking history found!";
		}
		
	print_r(json_encode($response));
}else

//3. daily_checkin - Daily checkin of user and Add Spin Points to user account
if(isset($access_key) && isset($daily_checkin)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
		$sql = mysqli_query($link,"select id from tracker where `username`='".$username."' and (`type`='Daily checkin bonus' or `type`='Daily checked In') and date(`date`)='".date('Y-m-d')."'");
		$result = mysqli_fetch_assoc($sql);
		
		if(mysqli_num_rows($sql)>0){
		    
			$response['error'] = false;
			$response['message'] = "You've already claimed your daily checkin bonus!";
			$response['id'] = $result['id'];
			print_r(json_encode($response));
			return false;
		}
            $tracker_query = mysqli_query($link,'INSERT INTO `tracker`(`username`, `points`, `type`, `date`) VALUES 
							("'.$username.'","'.$points.'","'.$type.'","'.date('Y-m-d').'")');		
			$sql = mysqli_query($link,"UPDATE `users` SET `points` = `points` + '".$points."' WHERE `users`.`username` ='".$username."'");
	        $result = mysqli_fetch_assoc($tracker_query);	
		
		    $response['error'] = false;
	    	$response['message'] = "Points added to your wallet";
	    	$response['id'] = $result['id'];
	    	print_r(json_encode($response));
}else
// 12. get_payment_requests() - get user's payment requests 
if(isset($access_key) && isset($get_payment_requests)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
    	$sql = mysqli_query($link,"SELECT * FROM `payment_requests` WHERE username='$username'");
	
	    $rows = array();
        while($r = mysqli_fetch_assoc($sql)) {
         $rows[] = $r;
        }

		if (!empty($sql)) {
			$response['error'] = "false";
			$response['data'] = $rows;
		}else{
			$response['error'] = "true";
			$response['message'] = "No data found!";
		}
	
		print_r(json_encode($response));
}else
// 13. update_fcm_id() - update user's fcm id
if(isset($access_key) && isset($update_fcm_id)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	$sql = mysqli_query($link,"UPDATE `users` SET `fcm_id`='".$fcm_id."' WHERE `username`='".$username."'");
	$response['error'] = "false";
	$response['message'] = "FCM ID updated successfully";
	print_r(json_encode($response));
}else
///

//14. Join Draw Game
if(isset($_POST['access_key']) && isset($_POST['join_draw'])){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	$check = mysqli_query($link,"SELECT * FROM lucky_draw WHERE id ='$game_id'");
	$data = mysqli_fetch_assoc($check);
	if($data['total_user']>=$data['total_allow_user']){
	    $response['error'] = "true";
		$response['message'] = "Lucky Draw Full";
		print_r(json_encode($response));
		return false;
	}
	
	if(!empty($username) && !empty($type)){
	
	    $adding_tracking_record = mysqli_query($link,'INSERT INTO `tracker`(`username`, `points`, `type`, `date`) VALUES 
							("'.$username.'","'.$points.'","'.$type.'","'.date('Y-m-d').'")');

		
		$sql = mysqli_query($link,"UPDATE `users` SET `points` = `points` + '".$points."' WHERE `users`.`username` ='".$username."'");
		
		/* Lucky Draw Table Joining Update +1 User Joined*/
		
		$sql = mysqli_query($link,"UPDATE `lucky_draw` SET `total_user` = `total_user` + 1 WHERE `lucky_draw`.`id` ='".$game_id."'") ;
		
	    /* Insert Join User Data to My_Contest Table to Remember user Details his joined*/
	    
	  	$sql = mysqli_query($link,'INSERT INTO `my_contests`(`game_id_name`, `game_name`, `username`,`game_email`,`game_result_date`,`game_prize`) VALUES 
							("'.$game_id.'","'.$game_name.'","'.$username.'","'.$game_email.'","'.$game_result_date.'","'.$game_prize.'")');
		$response['error'] = false;
		$response['message'] = "Registerd Successfuly";
		$response['id'] = mysqli_insert_id[$link];
	}else{
		$response['error'] = true;
		$response['message'] = "Please fill all the data and submit!";
	}
	print_r(json_encode($response));
}else

if(isset($access_key) && isset($get_luckydraw_list)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
       /* if($fcm_id) {
       // $sql = mysqli_query($link,"UPDATE `users` SET `fcm_id` = '".$fcm_id."' WHERE `users`.`email` ='".$email."'");
        }*/
        $sql=mysqli_query($link,"select * from lucky_draw WHERE status!=1 ORDER BY id DESC");
        
        $rows = array();
        while($r = mysqli_fetch_assoc($sql)) {
         $rows[] = $r; 
        }
       // print json_encode($rows);
        echo json_encode((['feed' => $rows]));
       
}else
// Get My Lucky Draw List////////////////////////////////////
if(isset($access_key) && isset($my_contests)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
        
     $sql=mysqli_query($link,"SELECT * FROM my_contests WHERE username = '$username' ORDER BY id DESC");
        $rows = array();
        $i=0;
       // $data = array('id'=>'0','game_id_name'=>'0', 'game_name'=>'0', 'username'=>'0', 'game_email'=>'0', 'game_win_status'=>'0', 'game_result_date'=>'0', 'game_prize'=>'0');
        while($r = mysqli_fetch_assoc($sql)) {
            $count = ($i+1)%3;
           if($count==0){
             // $rows[]=$data;
               $rows[] = $r;
           }else{
             $rows[] = $r;
           }
         
         
         $i++;
        }
       // print json_encode($rows);
        echo json_encode((['feed' => $rows]));
 
}else

// Get Game List////////////////////////////////////
if(isset($access_key) && isset($my_game)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
         $sql=mysqli_query($link,"select * from game_list");
        
        $rows = array();
        while($r = mysqli_fetch_assoc($sql)) {
            $game_id = $r['id'];
            $user = mysqli_query($link,"SELECT * FROM tbl_game_history WHERE game_id='$game_id' AND username='$username'");
            $res = mysqli_fetch_assoc($user);
            $data = array("replay"=>$res['replay'],"total_earning"=>$res['total_earning']);
            $rows[] = $r+$data;
        }
       echo json_encode((['feed' => $rows]));

}else

	
////// get UPI
if(isset($access_key) && isset($upi)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}

        $sql=mysqli_query($link,"select upi_name,upi_id from admin");
       
        $rows = array();
        while($r = mysqli_fetch_assoc($sql)) {
         $rows[] = $r;
        }
       echo json_encode((['feed' => $rows]));
 
}else

// Lucky Draw Result////////////////////////////////////
if(isset($access_key) && isset($contest_result)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}

         $sql=mysqli_query($link,"select * from draw_result where game_name = '$game_name'");
       
        
        //////
        $rows = array();
        while($r = mysqli_fetch_assoc($sql)) {
         $rows[] = $r;
        }
       // print json_encode($rows);
        echo json_encode((['feed' => $rows]));
   
}else

//////////////// GetActivity Data

if(isset($access_key) && isset($activity)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
         $sql = mysqli_query($link,"SELECT * FROM notifications ORDER BY id DESC");
         //////
        $rows = array();
        while($r = mysqli_fetch_assoc($sql)) {
         $rows[] = $r;
        }

        echo json_encode((['feed' => $rows]));
}else

// Insert Paid or Free Game Statics
if(isset($access_key) && isset($count_play)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	    if($free_game) {
	        $sql = mysqli_query($link,"UPDATE game_list SET free = free+1 WHERE id = '$id'");
	    } else {
	        $sql = mysqli_query($link,"UPDATE game_list SET paid = paid+1 WHERE id = '$id'");
	    }
         
         //////
        $rows = array();
        while($r = mysqli_fetch_assoc($sql)) {
         $rows[] = $r;
        }

        echo json_encode((['feed' => $rows]));
}else

//my Join Game
if(isset($access_key) && isset($my_join_game)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	$check = mysqli_query($link,"SELECT * FROM tbl_game_history WHERE username='$username' AND game_id='$game_id'");
	$res = mysqli_num_rows($check);
	if($res==1){
	    $update = mysqli_query($link,"UPDATE tbl_game_history set replay=replay+1 ,total_earning=total_earning+'$total_earning' WHERE username='$username' AND game_id='$game_id'");
	    if($update){
	        $response['error']=false;
	        $response['message']="Updated";
	    }else {
	         $response['error']=true;
	        $response['message']="Failed";
	    }
	}else {
	     $insert = mysqli_query($link,"INSERT INTO tbl_game_history SET replay=1,total_earning='$total_earning', username='$username', game_id='$game_id'");
	     if($insert){
	        $response['error']=false;
	        $response['message']="Inserted";
	    }else {
	         $response['error']=true;
	        $response['message']="Failed";
	    }
	}
	print_r(json_encode($response));
}else

/// Get Leaderboad
if(isset($access_key) && isset($leaderboard)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	$sql = mysqli_query($link,"SELECT name,points,username,image FROM users ORDER BY points DESC limit 10");
	
	    $rows = array();
	        $i=1;
            $rank=1;
            $flag="";
        while($r = mysqli_fetch_assoc($sql)) {
                        $pre=$r['points'];
                          if($flag!=$pre){
                               $flag=$pre;
                              if($i!=1){
                                 $rank=$i;
                                      //echo "count<br />";
                                    }
                                $i++;
                               $rank = ["rank"=>$rank];
                            }else{
                               $rank = $rank;
                            }
         $rows[] = $r + $rank;
        }
        echo json_encode((['feed' => $rows]));
        
}else
//get Admob Id
if(isset($access_key) && isset($admob)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	$sql = mysqli_query($link,"SELECT * FROM admob");
	
	    $rows = array();
        while($r = mysqli_fetch_assoc($sql)) {
         $rows[] = $r;
        }
        echo json_encode((['feed' => $rows]));
        
}else
//update password

if(isset($access_key) && isset($update_password)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	$select = mysqli_query($link,"SELECT * FROM users WHERE username='$username'");
	$s = mysqli_fetch_assoc($select);
	if($s['password']!=$old_pass){
	    $response['error'] = "true";
		$response['message'] = "Password Not Match";
		print_r(json_encode($response));
		return false;
	}
	

	   $insert = mysqli_query($link,"UPDATE users SET phone='$phone',email='$email', password='$new' WHERE username='$username'");
	   if($insert){
	        $response['error'] = "false";
		    $response['message'] = "Updated";
	   }else {
	        $response['error'] = "true";
		    $response['message'] = "Failed";
	   }

   print_r(json_encode($response));
}else
if(isset($access_key) && isset($check_user)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	$check = mysqli_query($link,"SELECT * FROM users WHERE phone='$phone'");
	if(mysqli_num_rows($check)>0){
	  //  $rand = rand(0000,9999);
	    $response['error']=false;
	    $response['message']="Already Account";
	}else {
	    $response['error']=true;
	    $response['message']="You are Not Registered !";
	}
	print_r(json_encode($response));
}else
/// update badege

if(isset($access_key) && isset($update_badge)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	$sql= mysqli_query($link, "UPDATE users SET badge = 0 WHERE username='$username'");
    
}else

//////////////////////

if(isset($access_key) && isset($user_point_update)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	        $update = mysqli_query($link,"SELECT * FROM users WHERE username='$username'");
	        $data = mysqli_fetch_assoc($update);
		   
			$response['error'] = "false";
			$response['message'] = "Successfully logged in";
			$response['data'] =$data;
			print_r(json_encode($response));
   }else



////////////////

////////////get Banner

if(isset($access_key) && isset($banner)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	$sql = mysqli_query($link,"SELECT * FROM banner");
	
	    $rows = array();
        while($r = mysqli_fetch_assoc($sql)) {
         $rows[] = $r;
        }
        echo json_encode((['feed' => $rows]));
        
}else

/////Check Update//////////////////
if(isset($access_key) && isset($update_version)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	$sql = mysqli_query($link,"SELECT * FROM tbl_update");
	
	$res = mysqli_fetch_assoc($sql);
	if($res['version']>$version) {
	    $response['error'] = "false";
	    $response['message'] = "Update Available";
	} else {
	    $response['error'] = "true";
	    $response['message'] = "You Are Using Latest Version of App";
	}
	
	 print_r(json_encode($response));
}else if
(isset($access_key) && isset($refer)){

	if($key != $access_key){
		$response['error'] = "true";
		$response['message'] = "Invalid Access Key";
		print_r(json_encode($response));
		return false;
	}
	
	$check = mysqli_query($link,"SELECT refer,refer_status,username FROM users WHERE refer='$refer' AND username!='$username'");
	$new = mysqli_query($link,"SELECT refer_status FROM users WHERE username='$username'");
	$banda = mysqli_fetch_assoc($new);
	if(mysqli_num_rows($check)!=1){
	    $response['error'] = "true";
		$response['message'] = "Invalid Refer Code";
		print_r(json_encode($response));
		return false;
	}
	$re = mysqli_fetch_assoc($check);
	if($banda['refer_status']==1){
	    $response['error'] = "true";
		$response['message'] = "Already Claim Refer";
		print_r(json_encode($response));
		return false;
	}
	$date = date("Y-m-d");
	$sharing_banda = $re['username'];
	$t = $type;
	$sql = mysqli_query($link,"UPDATE users SET points= points +10, refer_status=1 WHERE username='$username'");

	
	if($sql){
	    //$tracker = mysqli_query($link,"INSERT INTO tracker SET username='$username',points='10', date='$date',type='$type'");
	    $tracker1 = mysqli_query($link,"INSERT INTO tracker SET username='$sharing_banda',points='10',date='$date',type='Refer & Earn'");
	    $sql1 = mysqli_query($link,"UPDATE users SET points= points +10 WHERE username='$sharing_banda'");
	    $response['error'] = "false";
		$response['message'] = "Succesfull Claim Refer";
	}else {
	    $response['error'] = "true";
		$response['message'] = "Try Again";
	}
	
	print_r(json_encode($response));
}
?>




