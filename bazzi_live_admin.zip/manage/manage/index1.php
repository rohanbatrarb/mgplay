<?php include 'session.php';?>

<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="refresh" content="0;url=dashboard.php">
    <title>Quick Earn</title>
    <script language="javascript">
        window.location.href = "dashboard.php"
    </script>
</head>

<body>
    Go to <a href="dashboard.php">Please</a>
</body>

</html>
