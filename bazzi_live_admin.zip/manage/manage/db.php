

<?php

$link=mysqli_connect("localhost","u822810583_baazi", "9575832359@1","u822810583_baazi");

if($link){
	//echo "Connected";
} else {
	echo "Error";
}
?>