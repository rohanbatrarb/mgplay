<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Game List</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->

  <?php
  include 'db.php';
  include 'session.php';
  include  'nav_barr.php';
  ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Game List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Game List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
         <?php
          if(isset($_COOKIE['game_update'])){
                echo '<div class="alert alert-primary" role="alert">
          Updated Successfull!
        </div>';
                
            }else if(isset($_COOKIE['game_delete'])){
                echo '<div class="alert alert-danger" role="alert">
          Deleted!
        </div>';
            }
           ?>
        
        
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-6">
                         <h3 class="card-title">Showing All Lucky Draw</h3>
                    </div>
                     <div class="col-sm-6 text-right">
                        <a href="add_game.php"><button class="btn btn-success">+ Add</button></a>
                    </div>
                </div>
             
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-hover" >
                <thead>
                <tr >
                  <th>Name</th>
                  <th>Game Play</th>
                  <th>Icon</th>
                  <th>Oparate</th>
                  
                </tr>
                </thead>
                <tbody>
                 <?php
                  $str="SELECT * FROM game_list";
                  $query=mysqli_query($link,$str);
                  while($row=mysqli_fetch_array($query)){
                  $id_e = $row['id'];
                  $game_icon = $row['game_icon'];
                echo "<tr>
                <td>".$row['paid_game']."</td>
                <td><a href='".$row['game_url']."' target='_blank' class='btn btn-primary '>Play</a></td>
                <td><img src ='".$game_icon."' height='42' width='42' /></td>
                <td><a href='edit_game.php?id=".$row['id']."' class='btn btn-primary '>Edit</a>&nbsp;&nbsp;<input type='button' value='Delete' class='btn btn-danger' onclick='delete_game(".$row['id'].");'/></td>
             </tr>
          ";
}?>
                </tbody>
                <tfoot>
                
                </tfoot>
              </table>
                
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

         
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php include 'side_bar.php';?>
  <!-- /.content-wrapper -->
 <?php include 'footer.php';?>

  <!-- Control Sidebar -->
 
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<?php include 'common_js.php';?>
<!-- page script -->
<script>

  $(function () {
    $("#example1").DataTable();
    
  });
</script>
<script type="text/javascript">
function delete_game(id){
    var status_confirm=confirm("Are You Sure?");
    if(status_confirm){
      $.ajax({
        url:"all_update.php",
       data:"id="+id+"&game_delete="+1,
       //data:{"id":id},
        method:"POST",
        cache:false,
        success:function(result){
        var obj=JSON.parse(result);
        if(obj.result=="success"){
            location.href="game_list.php";
              }else{
                alert(result);
              }
        }
      })
    }

  }
 

</script>

</body>
</html>
