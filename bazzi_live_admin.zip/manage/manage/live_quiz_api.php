<?php 
include 'db.php';
extract($_REQUEST);
$response = array();
$date = date("Y-m-d");
//01. Get Quiz Category List

if(@$get_quiz_category){
    
	$sql = mysqli_query($link,"SELECT * FROM live_quiz_category WHERE status='Upcoming'");
	$data = array();
	$i = 0;
	while ($res=mysqli_fetch_assoc($sql)) {
	    $id = $res['id'];
	    $check = mysqli_query($link,"SELECT * FROM live_quiz_join WHERE username ='$username' AND quiz_id='$id'");
	    if(mysqli_num_rows($check)==0){
	        $data[]=$res;
	        $i++;
	    }
	}

	if($i>0){
		$response['error']=false;
		$response['message']="Sucessfully Fetch Data";
		$response['data']=$data;
	}else {
		$response['error']=true;
		$response['message']="Failed";
	}

	print_r(json_encode($response));

}

//02. Get All Peding Payment
if(@$get_quiz_join){

	$sql = mysqli_query($link,"SELECT * FROM live_quiz_join WHERE username ='$username'");

	
	$sql_row = mysqli_num_rows($sql);
    $data = array();
	while ($res=mysqli_fetch_assoc($sql)) {
		
		$id = $res['quiz_id'];
		$check = mysqli_query($link,"SELECT * FROM live_quiz_category WHERE id ='$id' AND status='Upcoming'");
		$re1 = mysqli_fetch_assoc($check);
		$row = mysqli_num_rows($check);
		if($row>0){
		    $data[]=$re1;
		}
		
	

	}

	if($row>0 && $sql_row>0){
		$response['error']=false;
		$response['message']="Sucessfully Fetch Data";
		$response['data']=$data;
	}else {
		$response['error']=true;
		$response['message']="No Item";
	}

	print_r(json_encode($response));

}

//03. Get Complete Quiz

if(@$get_quiz_complete){
    $check = mysqli_query($link,"SELECT * FROM live_quiz_join WHERE username='$username'");
	
   $i=0;
	$data = array();
	$count=0;
	while ($res=mysqli_fetch_assoc($check)) {
		
		$id = $res['quiz_id'];
		$sql = mysqli_query($link,"SELECT * FROM live_quiz_category WHERE status ='Complete' OR status ='Payment' AND id='$id'");
		$hh = mysqli_fetch_assoc($sql);
		$count = mysqli_num_rows($sql);
		if($count>0){
		    $data[]=$hh;
			$i++;

		}
		
	}

	    $data1 = array_reverse($data);
	
	
	

	if($i>0){
		$response['error']=false;
		$response['message']="Sucessfully Fetch Data";
		$response['data']=$data1;
		
	}else {
		$response['error']=$count;
		$response['message']="Failed";
	}

	print_r(json_encode($response));

}

//04. Join Live Quiz

if(@$join_live_quiz){
    $check = mysqli_query($link,"SELECT * FROM live_quiz_join WHERE username='$username' AND quiz_id='$id'");
    $join_check = mysqli_num_rows($check);
    if($join_check>0){
        	$response['error']=true;
    		$response['message']="Already Join";
    		print_r(json_encode($response));
    		return false;
    }
	$sql = mysqli_query($link,"SELECT * FROM live_quiz_category WHERE id='$id'");
	$res = mysqli_fetch_assoc($sql);
	$name = $res['quiz_name'];
	if($res['total_player']==$res['total_join']){
		$response['error']=true;
		$response['message']="Live Quiz Full Join Another";
		print_r(json_encode($response));
		return false;
	}
	$points1 = mysqli_query($link,"SELECT * FROM users WHERE username='$username'");
	$r = mysqli_fetch_assoc($points1);
	$ent = $entry_fee;
	if($r['points']<$ent){
		$response['error']=true;
		$response['message']="You have Not Enough Coins To Join";
		print_r(json_encode($response));
		return false;
	}
	$date = date("Y-m-d");

	$insert = mysqli_query($link,"INSERT INTO live_quiz_join SET username='$username',quiz_id='$id',entry_date='$date',rank='0',score='0',amount='0'");
	if($insert){
	    $tracker = mysqli_query($link,"INSERT INTO tracker SET username='$username',points='-$ent',date='$date',type='$name Live Quiz Join'");
	    $update = mysqli_query($link,"UPDATE users SET points = points-$ent WHERE username='$username'");
	    $category = mysqli_query($link,"UPDATE live_quiz_category SET total_join=total_join+1 WHERE id='$id'");
	    $response['error']=false;
		$response['message']="Successfull Join";
	}else {
	    $response['error']=true;
		$response['message']="Failed";
	}
	
	print_r(json_encode($response));
}

//05. Get by ID

if(@$details_by_id){
    $mention = mysqli_query($link,"SELECT * FROM live_quiz_join WHERE quiz_id='$id' AND username='$username'");
    $row = mysqli_num_rows($mention);
    $t_status = mysqli_fetch_assoc($mention);
    $st = $t_status['tbl_status'];
    if($row==0){
        $st = 0;
    }
    $sql = mysqli_query($link,"SELECT * FROM live_quiz_category WHERE id='$id'");
    $res = mysqli_fetch_assoc($sql);
  
    if($sql){
        $response['error']=false;
        $response['message']="Succesfull Fetch Data";
        $response['data']=[$res+array('join_status'=>$row,'t_status'=>$st,'win'=>$t_status['amount'])];
    }else {
         $response['error']=true;
        $response['message']="Failed";
        
    }
    print_r(json_encode($response));
}

//06. get_prize_distribution

if(@$get_prize_distribution){
    
    $sql = mysqli_query($link,"SELECT * FROM live_quiz_distribution WHERE quiz_id='$id'");
    $data = array();
    while($res=mysqli_fetch_assoc($sql)){
        $data[]=$res;
    }
    if($sql){
         $response['error']=false;
        $response['message']="Succesfull Fetch Data";
        $response['data']=$data;
    }else {
         $response['error']=true;
        $response['message']="Failed";
    }
    print_r(json_encode($response));
}
//0. get_prize_ranking
if(@$get_prize_ranking){
    $sql = mysqli_query($link,"SELECT * FROM live_quiz_join WHERE quiz_id='$id' ORDER by score DESC");
    $data = array();
     $i=1;
      $rank=1;
    $flag="";
    while($res=mysqli_fetch_assoc($sql)){
        $pre=$res['score'];
                          if($flag!=$pre){
                               $flag=$pre;
                              if($i!=1){
                                 $rank=$i;
                                      //echo "count<br />";
                                    }
                                $i++;
                               $rank = $rank;
                            }else{
                               $rank = $rank;
                            }
            $username=$res['username'];
            $rank_define = mysqli_query($link,"UPDATE live_quiz_join SET rank = '$rank' WHERE username = '$username'");
       // $data[]=$res;
        
    }
    $new = mysqli_query($link,"SELECT * FROM live_quiz_join WHERE quiz_id='$id' ORDER by score DESC");
    while($r=mysqli_fetch_assoc($new)){
        $data[]=$r;
    }
    if($sql){
         $response['error']=false;
        $response['message']="Succesfull Fetch Data";
        $response['data']=$data;
    }else {
         $response['error']=true;
        $response['message']="Failed";
    }
    print_r(json_encode($response));
}
// Get Question 

if(@$get_question_by_id){
    $sql = mysqli_query($link,"SELECT * FROM live_quiz_question WHERE quiz_id='$id'");
    $data = array();
    mysqli_set_charset( $link, 'utf8');
    while($res=mysqli_fetch_assoc($sql)){
        $data[]=$res;
    }
    if(mysqli_num_rows($sql)>0){
        $response['error']=false;
        $response['message']="Successfull Question Fetch";
        $response['question']=$data;
    }else {
        $response['error']=true;
        $response['message']="Failed";
       
    }
    
    print_r(json_encode($response));
}

//Insert User Answer

if(@$user_answer){
    
    $check = mysqli_query($link,"SELECT * FROM live_quiz_user_answer WHERE tbl_quiz='$quiz_id' AND question_id='$question_id' AND username='$username'");
    if(mysqli_num_rows($check)>0){
        $update = mysqli_query($link,"UPDATE live_quiz_user_answer SET answer='$answer', left_time='$left_time',score='$score' WHERE tbl_quiz='$quiz_id' AND question_id='$question_id' AND username='$username'");
        $complete = mysqli_query($link,"UPDATE live_quiz_join SET tbl_status=1 WHERE quiz_id='$quiz_id' AND username='$username'");
     //  $user = mysqli_query($link,"UPDATE live_quiz_join SET score=score+'$score'+'$left_time' WHERE username='$username' AND quiz_id='$quiz_id'");
        if($update){
            $response['error']=false;
            $response['message']="Successfull Update";
            
        }else {
             $response['error']=true;
            $response['message']="Update Failed";
        }
    }else {
        $complete = mysqli_query($link,"UPDATE live_quiz_join SET tbl_status=1 WHERE quiz_id='$quiz_id' AND username='$username'");
        $user = mysqli_query($link,"UPDATE live_quiz_join SET score=score+'$score'+'$left_time' WHERE username='$username' AND quiz_id='$quiz_id'");
        $insert = mysqli_query($link,"INSERT INTO live_quiz_user_answer SET answer='$answer',tbl_quiz='$quiz_id', question_id='$question_id', left_time='$left_time',score='$score', username='$username'");
         if($insert){
            $response['error']=false;
            $response['message']="Successfull Insert";
            
        }else {
            $response['error']=true;
            $response['message']="Insert Failed";
        }
    }
    
    print_r(json_encode($response));
}
///Review Question

if(@$review_question){
    $sql = mysqli_query($link, "SELECT * FROM live_quiz_user_answer WHERE tbl_quiz='$quiz_id' AND username='$username'");
    $data = array();
    $total_score = 0;
    $th = "";
    if(mysqli_num_rows($sql)>0){
        while($res=mysqli_fetch_assoc($sql)){
        $id = $res['question_id'];
        //$u_score = $res['score'];
       /// $u_left = $res['left_time'];
        //$th = $the+$u_score+$u_left;
        //$user = mysqli_query($link,"UPDATE live_quiz_join SET score=score+$th WHERE username='$username' AND quiz_id='$quiz_id'");
        $question = mysqli_query($link,"SELECT * FROM live_quiz_question WHERE id = '$id'");
        $re = mysqli_fetch_assoc($question);
        $the = array_merge($res, $re);
        $data[]= $the; 
        
        }
        //$update = mysqli_query($link,"UPDATE live_quiz_join SET score='$th' WHERE username='$username' AND tbl_quiz='$quiz_id'");
    }else {
        $sql1 = mysqli_query($link, "SELECT * FROM live_quiz_question WHERE quiz_id='$quiz_id'");
        while($res1=mysqli_fetch_assoc($sql1)){
        $data[]= array_merge($res1,array('id'=>0,'tbl_quiz'=>0,'answer'=>0,'score'=>0,'left_time'=>0)); 
        }
        
    }
    
   
    if($sql) {
        $response['error']=false;
        $response['message']="Success to Fetch Data";
        $response['data']=$data;
    }else {
        $response['error']=true;
        $response['message']="Failed";
        
    }
    //echo "SELECT * FROM live_quiz_user_answer WHERE tbl_quiz='$quiz_id' AND username='$username'";
    print_r(json_encode($response));
}
/// Times Up 

if(@$times_up){
    $sql = mysqli_query($link,"UPDATE live_quiz_category SET status='Payment' WHERE id='$quiz_id'");
    if($sql){
        $response['error']=false;
        $response['message']="Updated Successful";
    }else{
        $response['error']=true;
        $response['message']="Update Failed";
    }
    print_r(json_encode($response));
}
?>